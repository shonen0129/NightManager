"""TachibanaBrokerClient — BrokerClient adapter for Tachibana Securities API.

Adapts TachibanaClient to conform to the BrokerClient interface.
"""

from __future__ import annotations

import logging
import os
import time
from collections.abc import Callable
from datetime import datetime
from typing import Any, cast

from leadlag.broker.base import BrokerClient, BrokerConfig, Position, WalletInfo
from leadlag.broker.tachibana import session_cache
from leadlag.broker.tachibana.api import TachibanaApiError, TachibanaClient
from leadlag.config import TachibanaApiConfig
from leadlag.core.types import (
    OrderRequest,
    OrderResult,
    OrderSide,
    OrderStatus,
    OrderType,
)

logger = logging.getLogger(__name__)


class TachibanaBrokerClient(BrokerClient):
    """BrokerClient implementation backed by Tachibana Securities API.

    Translates between the broker-neutral interface and Tachibana-specific types.
    """

    def __init__(self, config: BrokerConfig) -> None:
        self._broker_config = config
        self._api_config = self._build_api_config(config)
        self._client = TachibanaClient(self._api_config)

    def _build_api_config(self, config: BrokerConfig) -> TachibanaApiConfig:
        """Translate neutral BrokerConfig to TachibanaApiConfig."""
        # Check config parameters with fallback to environment variables
        auth_id = (
            config.api_token
            or config.extra.get("auth_id")
            or os.environ.get("TACHIBANA_AUTH_ID", "")
        )
        private_key_path = (
            config.extra.get("private_key_path")
            or os.environ.get("TACHIBANA_PRIVATE_KEY_PATH", "")
        )

        # Security check: verify private key file has restrictive permissions
        if private_key_path and os.path.exists(private_key_path):
            import stat
            file_stat = os.stat(private_key_path)
            file_mode = stat.filemode(file_stat.st_mode)
            # Check if file is readable by group or others (should be 600 or 400)
            if file_stat.st_mode & (stat.S_IRGRP | stat.S_IROTH):
                logger.warning(
                    "SECURITY WARNING: Private key file %s has overly permissive permissions (%s). "
                    "Recommended: chmod 600 (owner read/write only)",
                    private_key_path, file_mode
                )
        second_password = (
            config.api_password
            or config.extra.get("second_password")
            or os.environ.get("TACHIBANA_SECOND_PASSWORD", "")
        )

        return TachibanaApiConfig(
            api_url=config.api_url or "https://kabuka.e-shiten.jp/e_api_v4r9",
            auth_id=auth_id,
            private_key_path=private_key_path,
            second_password=second_password,
            request_timeout=config.request_timeout,
            margin_trade_type=config.margin_trade_type,
            account_type=config.account_type,
        )

    def close(self) -> None:
        self._client.close()

    def release_session(self) -> None:
        """Hand the authenticated server session to the next pipeline process."""
        self._client.release_session()

    def restore_session(self) -> bool:
        """Restore session state from disk if a cache exists."""
        state = session_cache.load_session_cache()
        if not state:
            return False
        return self._client.restore_session(state)

    def discard_restored_session(self) -> None:
        """Discard invalid restored state before a fresh login attempt."""
        self._client.discard_restored_session()

    def get_order_detail(self, order_number: str, eigyou_day: str) -> dict[str, Any]:
        """Fetch order detail with fill information (約定価格、約定株数).

        Args:
            order_number: Order ID from submit_order response
            eigyou_day: Business day string (YYYYMMDD)

        Returns:
            Dict with sYakuzyouPrice, sYakuzyouSuryou, sYakuzyouDate,
            aYakuzyouSikkouList (partial fills), aKessaiOrderTategyokuList (settlement details).
        """
        return self._client.get_order_detail(order_number, eigyou_day)

    def health_check(self) -> bool:
        """Check connection by attempting to login and retrieve price for a test ticker."""
        try:
            if not self._client.logged_in:
                self._client.login()
            # Perform a test query using TOPIX ticker or sector ETF (e.g. "1617")
            res = self._client.get_price(["1617"])
            return len(res) > 0
        except Exception as e:
            logger.error("Tachibana health check failed: %s", e)
            return False

    def get_wallet(self) -> WalletInfo:
        """Retrieve cash and margin balance information."""
        res = self._client.get_wallet()
        cash = float(res.get("sGenbutuKabuKaituke", 0.0))
        margin = float(res.get("sSinyouSinkidate", 0.0))

        # Fetch margin detail for 受入保証金 (deposited margin = equity base)
        ukeire_hosyoukin = None
        hosyoukin_yoryoku = None
        hosyoukin_ritu = None
        try:
            detail = self._client.get_margin_detail(hituke_index=0)
            ukeire_hosyoukin = float(detail.get("sUkeireHosyoukin", 0.0))
            hosyoukin_yoryoku = float(detail.get("sHosyoukinYoryoku", 0.0))
            hosyoukin_ritu = float(detail.get("sHosyoukinRitu", 0.0))
        except Exception as e:
            logger.warning("Failed to fetch margin detail: %s", e)

        return WalletInfo(
            cash_available=cash,
            margin_available=margin,
            extra={
                "ukeire_hosyoukin": ukeire_hosyoukin,
                "hosyoukin_yoryoku": hosyoukin_yoryoku,
                "hosyoukin_ritu": hosyoukin_ritu,
                "sHosyouKinritu": res.get("sHosyouKinritu"),
                "sOisyouHasseiFlg": res.get("sOisyouHasseiFlg"),
                "sTatekaekinHasseiFlg": res.get("sTatekaekinHasseiFlg"),
            },
        )

    def _fetch_prices(
        self,
        tickers: list[str],
        price_field: str,
        label: str,
        *,
        allow_missing: bool = False,
    ) -> dict[str, float]:
        """Fetch prices from Tachibana API for JP tickers.

        Args:
            tickers: List of tickers in yfinance format (e.g. '1617.T')
            price_field: API field name ('pDOP' for open, 'pDPP' for current)
            label: Label for log messages (e.g. 'open', 'current')
            allow_missing: If True, return partial results instead of raising

        Returns:
            Dict mapping ticker → price
        """
        prices: dict[str, float] = {}
        missing_tickers: list[str] = []

        mapping = {tk.replace(".T", ""): tk for tk in tickers}
        clean_codes = list(mapping.keys())

        chunk_size = 100
        for i in range(0, len(clean_codes), chunk_size):
            chunk = clean_codes[i : i + chunk_size]
            try:
                res = self._client.get_price(chunk)
                for item in res:
                    code = item.get("sIssueCode")
                    price_str = item.get(price_field)
                    if code is None:
                        continue
                    original_ticker = mapping.get(code)
                    if not original_ticker:
                        continue

                    try:
                        price = float(price_str) if price_str and price_str != "0.0000" else 0.0
                    except ValueError:
                        price = 0.0

                    if price > 0.0:
                        prices[original_ticker] = price
                    else:
                        missing_tickers.append(original_ticker)
            except Exception as e:
                logger.error("Failed to fetch price chunk %s: %s", chunk, e)
                for code in chunk:
                    missing_tickers.append(mapping[code])

        for tk in tickers:
            if tk not in prices and tk not in missing_tickers:
                missing_tickers.append(tk)

        if missing_tickers:
            msg = f"Failed to fetch {label} prices for {len(missing_tickers)} ticker(s): {', '.join(missing_tickers)}"
            if allow_missing:
                logger.warning(msg)
            else:
                logger.error(msg)
                raise ValueError(msg)

        return prices

    def fetch_open_prices(
        self,
        tickers: list[str],
        *,
        allow_missing: bool = False,
    ) -> dict[str, float]:
        """Fetch today's open prices for JP tickers (e.g. '1617.T')."""
        return self._fetch_prices(tickers, "pDOP", "open", allow_missing=allow_missing)

    def fetch_current_prices(
        self,
        tickers: list[str],
        *,
        allow_missing: bool = False,
    ) -> dict[str, float]:
        """Fetch current real-time prices for JP tickers (e.g. '1617.T')."""
        return self._fetch_prices(tickers, "pDPP", "current", allow_missing=allow_missing)

    def fetch_us_etf_returns(
        self,
        us_tickers: list[str],
    ) -> dict[str, float]:
        """Fetch US ETF returns.

        Tachibana API is JP only; uses yfinance dynamically as a fallback.
        """
        logger.info("[TachibanaBroker] Fetching US ETF returns via yfinance fallback...")
        import yfinance as yf

        from leadlag.utils.threading import run_with_timeout

        _YF_TIMEOUT = 30

        returns: dict[str, float] = {}
        failed: list[str] = []

        for ticker in us_tickers:
            try:
                t_obj = yf.Ticker(ticker)

                hist = run_with_timeout(
                    cast(Callable[[], Any], lambda _tobj=t_obj: _tobj.history(period="5d")),
                    _YF_TIMEOUT,
                    label=f"yf.Ticker({ticker}).history()",
                )

                if len(hist) >= 2:
                    last_close = hist["Close"].iloc[-1]
                    prev_close = hist["Close"].iloc[-2]
                    returns[ticker] = float(last_close / prev_close - 1.0)
                else:
                    failed.append(ticker)
            except Exception as e:
                logger.error("yfinance US return fetch failed for %s: %s", ticker, e)
                failed.append(ticker)

        if failed:
            logger.warning(
                "Failed to fetch returns for %d US ETF(s): %s",
                len(failed),
                ", ".join(failed),
            )
        logger.info("Successfully fetched returns for %d/%d US ETFs", len(returns), len(us_tickers))
        return returns

    def get_positions(self, **filters: Any) -> list[Position]:
        """Fetch current open credit positions."""
        raw = self._client.get_positions(ticker=filters.get("symbol"))
        positions: list[Position] = []

        for pos in raw:
            issue_code = str(pos.get("sOrderIssueCode", ""))
            ticker = f"{issue_code}.T" if issue_code and not issue_code.endswith(".T") else issue_code

            # Side mapping: "3"=BUY, "1"=SELL
            side_raw = str(pos.get("sOrderBaibaiKubun", ""))
            side = "BUY" if side_raw == "3" else "SELL"

            # Bensai mapping: neutral code mapping
            # Tachibana: 26=制度6ヶ月, 36=一般6ヶ月
            bensai_raw = str(pos.get("sOrderBensaiKubun", ""))
            neutral_margin = 1 if bensai_raw == "26" else 3

            # Account type mapping: "1"=特定, "3"=一般 -> neutral: 4=特定, 2=一般
            acc_raw = str(pos.get("sOrderZyoutoekiKazeiC", ""))
            neutral_acc = 4 if acc_raw == "1" else 2

            positions.append(
                Position(
                    ticker=ticker,
                    side=side,
                    quantity=int(pos.get("sOrderTategyokuSuryou", 0)),
                    price=float(pos.get("sOrderTategyokuTanka", 0.0)),
                    exchange=0, # Not applicable
                    execution_id=str(pos.get("sOrderTategyokuNumber", "")),
                    margin_trade_type=neutral_margin,
                    account_type=neutral_acc,
                    extra={
                        "sOrderHensaiKanouSuryou": int(pos.get("sOrderHensaiKanouSuryou", 0)),
                        "sOrderTategyokuDay": pos.get("sOrderTategyokuDay"),
                        "sOrderTategyokuKizituDay": pos.get("sOrderTategyokuKizituDay"),
                        "sOrderGaisanHyoukaSoneki": pos.get("sOrderGaisanHyoukaSoneki"),
                        "sOrderHyoukaTanka": pos.get("sOrderHyoukaTanka"),
                        "sOrderGaisanHyoukaSonekiRitu": pos.get("sOrderGaisanHyoukaSonekiRitu"),
                        "sOrderTategyokuDaikin": pos.get("sOrderTategyokuDaikin"),
                        "sOrderTateTesuryou": pos.get("sOrderTateTesuryou"),
                        "sOrderZyunHibu": pos.get("sOrderZyunHibu"),
                        "sOrderGyakuhibu": pos.get("sOrderGyakuhibu"),
                        "sOrderKasikaburyou": pos.get("sOrderKasikaburyou"),
                    },
                )
            )
        return positions

    def submit_order(
        self,
        order: OrderRequest,
        *,
        is_close: bool = False,
        close_position_order: int = 0,
    ) -> OrderResult:
        clean_ticker = order.ticker.replace(".T", "")

        # Side mapping: buy -> "3", sell -> "1"
        side_code = "3" if order.side == OrderSide.BUY else "1"

        # Margin Trade Type mapping
        # 1 = 制度信用 (Tachibana: 2=新規, 4=返済)
        # 2, 3 = 一般信用 (Tachibana: 6=新規, 8=返済)
        if close_position_order and is_close:
            logger.warning(
                "Tachibana API does not support close_position_order (%d); "
                "it will be ignored. Specific position repayment is not available.",
                close_position_order,
            )

        m_type = order.margin_trade_type if order.margin_trade_type is not None else self._broker_config.margin_trade_type
        if is_close:
            genkin_shinyou = "4" if m_type == 1 else "8"
        else:
            genkin_shinyou = "2" if m_type == 1 else "6"

        # Account Type mapping
        # 4 (特定) -> "1", 2 (一般) -> "3", 12 (法人) -> "9"
        acc_type = order.account_type if order.account_type is not None else self._broker_config.account_type
        account_code = "1"
        if acc_type == 2:
            account_code = "3"
        elif acc_type == 12:
            account_code = "9"

        # Order Type mapping
        # MARKET -> condition="0", price="0"
        # LIMIT -> condition="0", price=str(limit_price)
        # CLOSE -> condition="4" (引け), price="0"
        condition = "0"
        price_str = "0"

        if order.order_type == OrderType.LIMIT:
            if order.limit_price is None:
                raise ValueError("Limit price is required for limit orders")
            price_str = str(order.limit_price)
        elif order.order_type == OrderType.CLOSE:
            condition = "4"

        try:
            res = self._client.send_order(
                ticker=clean_ticker,
                side=side_code,
                quantity=order.quantity,
                order_price=price_str,
                condition=condition,
                genkin_shinyou=genkin_shinyou,
                account_type=account_code,
                is_close=is_close,
            )

            order_id = str(res.get("sOrderNumber", ""))
            eigyou_day = str(res.get("sEigyouDay", ""))
            return OrderResult(
                order_id=order_id,
                status=OrderStatus.SUBMITTED,
                ticker=order.ticker,
                side=order.side,
                quantity=order.quantity,
                order_type=order.order_type,
                limit_price=order.limit_price,
                margin_trade_type=self._broker_config.margin_trade_type,
                eigyou_day=eigyou_day,
            )

        except (TachibanaApiError, ValueError) as e:
            logger.error("Tachibana order failed for %s: %s", order.ticker, e)
            return OrderResult(
                order_id="",
                status=OrderStatus.FAILED,
                ticker=order.ticker,
                side=order.side,
                quantity=order.quantity,
                order_type=order.order_type,
                limit_price=order.limit_price,
                message=str(e),
            )

    def get_order_status(self, order_id: str) -> OrderStatus:
        """Poll Tachibana order detail and map to neutral OrderStatus."""
        eigyou_day = datetime.now().strftime("%Y%m%d")
        try:
            detail = self._client.get_order_detail(order_id, eigyou_day)
        except Exception:
            return OrderStatus.SUBMITTED

        # Execution quantity (total filled) and ordered quantity.
        # CLMOrderListDetail uses the ``sOrder*`` names.  The similarly named
        # fields in the order request (``sOrderSuryou``) must not be used here.
        cum_qty = int(detail.get("sYakuzyouSuryou", 0) or 0)
        order_qty = int(detail.get("sOrderOrderSuryou", 0) or 0)
        status_code = str(detail.get("sOrderStatusCode", "")).strip()

        # Prefer the broker's terminal status code.  Quantity is also checked
        # because a broker can report a filled quantity before the status list
        # catches up.  Expiry is terminal even when only part of the order was
        # executed; it must not be mistaken for a still-live partial order.
        if status_code == "10":
            return OrderStatus.FILLED
        if status_code == "7":
            # Cancellation is terminal even when a portion was executed.
            return OrderStatus.CANCELLED
        if status_code in {"11", "12", "19"}:
            # 一部/全部失効 and 繰越失効 are terminal broker outcomes.  The
            # fill quantity remains available through get_order_detail for
            # reconciliation; the neutral state only controls polling.
            return OrderStatus.CANCELLED
        if status_code in {"5", "8"}:
            # 訂正失敗/取消失敗 describe the request, not necessarily the
            # original order.  Keep polling the original order until its own
            # terminal status is confirmed.
            if order_qty > 0 and cum_qty >= order_qty:
                return OrderStatus.FILLED
            if cum_qty > 0:
                return OrderStatus.PARTIALLY_FILLED
            return OrderStatus.SUBMITTED
        if status_code in {"2", "14", "17", "20", "21"}:
            # These are explicit rejection/invalid/abnormal terminal outcomes.
            # Do not let a contradictory quantity field turn them into FILLED.
            return OrderStatus.FAILED
        if status_code == "9" or (cum_qty > 0 and order_qty > cum_qty):
            return OrderStatus.PARTIALLY_FILLED
        if order_qty > 0 and cum_qty >= order_qty:
            # Quantity is a fallback only when the broker has not supplied a
            # contradictory terminal status code.
            return OrderStatus.FILLED

        # 0/1/3/4/6/13/15/16/50 are in-flight or non-terminal states.  An
        # unknown code is deliberately kept pending so it cannot be counted as
        # a successful order or trigger an unsafe retry.
        return OrderStatus.SUBMITTED

    def submit_orders_batch(
        self,
        orders: list[OrderRequest],
        *,
        delay_ms: int = 250,
        is_close: bool = False,
        close_position_order: int = 0,
    ) -> list[OrderResult]:
        """Place multiple orders with delay between each to avoid rate limits."""
        if not orders:
            return []

        logger.info(
            "[TachibanaBroker] Submitting %d batch orders (is_close=%s)...",
            len(orders),
            is_close,
        )

        results: list[OrderResult] = []
        for i, order in enumerate(orders):
            if i > 0:
                time.sleep(delay_ms / 1000.0)

            res = self.submit_order(
                order,
                is_close=is_close,
                close_position_order=close_position_order,
            )
            results.append(res)

        # --- Market-Neutrality Rollback Check ---
        # Skip rollback for close orders (返済) — they reduce positions, not open new ones.
        # Partial close failures are acceptable; the decision run will report them.
        accepted_statuses = {
            OrderStatus.SUBMITTED,
            OrderStatus.PARTIALLY_FILLED,
            OrderStatus.FILLED,
            OrderStatus.SIMULATED,
        }
        if is_close:
            success = sum(1 for r in results if r.status in accepted_statuses)
            logger.info("Batch close submission complete: %d/%d orders successful.", success, len(orders))
            return results

        buy_total = sum(1 for o in orders if o.side == OrderSide.BUY)
        sell_total = sum(1 for o in orders if o.side == OrderSide.SELL)
        buy_success = sum(
            1 for r in results if r.side == OrderSide.BUY and r.status in accepted_statuses
        )
        sell_success = sum(
            1 for r in results if r.side == OrderSide.SELL and r.status in accepted_statuses
        )
        buy_fail = buy_total - buy_success
        sell_fail = sell_total - sell_success

        needs_rollback = False
        if buy_total > 0 and buy_fail >= buy_total / 2:
            logger.error(
                "BUY side failure rate too high: %d/%d. Triggering rollback.",
                buy_fail,
                buy_total,
            )
            needs_rollback = True
        if sell_total > 0 and sell_fail >= sell_total / 2:
            logger.error(
                "SELL side failure rate too high: %d/%d. Triggering rollback.",
                sell_fail,
                sell_total,
            )
            needs_rollback = True

        if needs_rollback:
            logger.error("Rolling back %d successful orders due to imbalanced execution.", len(results))
            manual_interventions = []

            # Try to cancel successful orders
            # Tachibana cancel requires sEigyouDay from the order response;
            # fall back to system date if not available.
            for r in results:
                if r.status != OrderStatus.SUBMITTED or not r.order_id:
                    continue

                eigyou_day = r.eigyou_day or datetime.now().strftime("%Y%m%d")
                try:
                    # Cancel order
                    self._client.cancel_order(r.order_id, eigyou_day)
                    logger.info("Cancelled order: %s", r.order_id)
                except Exception as e:
                    logger.error("Failed to cancel order %s: %s", r.order_id, e)
                    opposite_side = "SELL" if r.side == OrderSide.BUY else "BUY"
                    instruction = (
                        f"[Ticker: {r.ticker}] Cancel failed. Please check position. "
                        f"If executed, manually perform opposite trade: {opposite_side} {r.quantity} shares. "
                        f"(Order ID: {r.order_id})"
                    )
                    manual_interventions.append(instruction)

            if manual_interventions:
                logger.critical("================ 🚨 EMERGENCY: MANUAL RESTORATION REQUIRED 🚨 ================")
                logger.critical("Batch order execution failed to maintain market neutrality.")
                logger.critical("Please execute opposite trades manually for the following items:")
                for msg in manual_interventions:
                    logger.critical("  -> %s", msg)
                logger.critical("==========================================================================")
            else:
                logger.info("All successful orders in batch successfully cancelled. No manual action required.")

            return [
                OrderResult(
                    order_id=r.order_id,
                    status=OrderStatus.CANCELLED,
                    ticker=r.ticker,
                    side=r.side,
                    quantity=r.quantity,
                    message="Cancelled by market-neutrality rollback",
                )
                for r in results
            ]

        logger.info("Batch submission complete: %d/%d orders successful.", len(results), len(orders))
        return results
