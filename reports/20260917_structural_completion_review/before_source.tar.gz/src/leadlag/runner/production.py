"""One-step production runner for the V2 lead-lag pipeline.

This module provides a high-level ``ProductionRunner`` that wires the
BLOX model, the V2 portfolio model, and the optional ML order overlay into
a single ``run()`` call.  It is intended to be used by ``leadlag.cli`` and
by the backtest engine.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from leadlag.config.schemas import AppConfig
from leadlag.data.pit_lake import MarketSnapshot, PITDataLake
from leadlag.data.tickers import JP_TICKERS
from leadlag.domain.inputs import DecisionInputs
from leadlag.domain.portfolio import PortfolioDecision
from leadlag.runner.model_factory import build_v2_model_bundle

logger = logging.getLogger(__name__)

__all__ = ["ProductionRunner", "RunnerInputs"]


@dataclass(frozen=True)
class RunnerInputs:
    """Inputs required for the production decision.

    Attributes:
        trade_date: Execution date in ``YYYY-MM-DD`` format.
        df_exec: Pre-processed execution DataFrame (index must contain trade_date).
        gap_input_dir: Directory containing the Step 2 gap-adjusted distribution
            cache (``mu_gap_YYYYMMDD.npy`` / ``omega_gap_YYYYMMDD.npy``), or
            ``None`` to force on-demand computation / flat fallback.
        current_prices: Mapping from JP tickers to 09:10 JPY prices.
        use_file_cache: Prefer pre-computed ``.npy`` file cache when available.
        previous_positions: Optional mapping of currently held share counts.
        lake: Optional PITDataLake wrapping ``df_exec``. If provided, the runner
            uses ``lake.df_exec`` and ``lake.get_snapshot(trade_date)`` as the
            single source of point-in-time data.
        snapshot: Optional pre-computed MarketSnapshot for ``trade_date``. When
            supplied, ``snapshot.current_prices`` becomes the source of truth.
        decision_inputs: Optional versioned ``DecisionInputs`` contract. When
            supplied, it is the only data object passed into the model.
    """

    trade_date: str | None = None
    df_exec: pd.DataFrame | None = None
    gap_input_dir: Path | None = None
    current_prices: dict[str, float] = field(default_factory=dict)
    use_file_cache: bool = True
    previous_positions: dict[str, int] | None = None
    lake: PITDataLake | None = None
    snapshot: MarketSnapshot | None = None
    decision_inputs: DecisionInputs | None = None


class ProductionRunner:
    """High-level runner that orchestrates the full V2 decision flow."""

    def __init__(self, app_config: AppConfig) -> None:
        """Initialize the runner from a top-level application config.

        Args:
            app_config: A validated ``AppConfig``.
        """
        self.app_config = app_config

        bundle = build_v2_model_bundle(app_config)
        self._overlay_enabled = bundle.overlay_enabled
        self.model = bundle.decision_model

    def run(self, inputs: RunnerInputs) -> PortfolioDecision:
        """Generate the V2 portfolio decision for the supplied inputs.

        Args:
            inputs: A frozen ``RunnerInputs`` dataclass.

        Returns:
            ``PortfolioDecision`` from ``ProductionV2Model.decide``.

        Raises:
            ValueError: If ``df_exec`` is empty or ``trade_date`` is not in the
                index.
        """
        decision_inputs = inputs.decision_inputs
        if decision_inputs is None:
            # Legacy parallel fields are reconciled once at this outer adapter
            # boundary. The decision engine receives one immutable contract.
            if inputs.trade_date is None:
                raise ValueError("trade_date is required when decision_inputs is not supplied")
            lake = inputs.lake
            if lake is None:
                if inputs.df_exec is None or inputs.df_exec.empty:
                    raise ValueError("df_exec or lake must provide a non-empty DataFrame")
                lake = PITDataLake(inputs.df_exec)
            if pd.Timestamp(inputs.trade_date).normalize() not in lake.available_dates_up_to(inputs.trade_date):
                raise ValueError(
                    f"trade_date {inputs.trade_date} not found in df_exec index"
                )
            explicit_prices = None if inputs.snapshot is not None else inputs.current_prices
            decision_inputs = lake.build_decision_inputs(
                inputs.trade_date,
                snapshot=inputs.snapshot,
                current_prices=explicit_prices,
                gap_input_dir=inputs.gap_input_dir,
                use_file_cache=inputs.use_file_cache,
                source="runner_legacy_adapter",
            )
        elif inputs.trade_date is not None and decision_inputs.trade_date != pd.Timestamp(inputs.trade_date).normalize():
            raise ValueError(
                f"decision_inputs trade_date {decision_inputs.trade_date.date()} does not match "
                f"RunnerInputs trade_date {inputs.trade_date}"
            )

        price_source = decision_inputs.known.current_prices

        missing_prices = [t for t in JP_TICKERS if t not in price_source]
        if missing_prices:
            logger.warning(
                "current_prices missing tickers %s; treating them as 0 gap",
                missing_prices,
            )

        return self.model.decide(
            inputs=decision_inputs,
            overlay_enabled=self._overlay_enabled,
            use_file_cache=decision_inputs.use_file_cache,
        )
