"""Historical daily return cache for VaR/ES risk checks.

This module was split from ``leadlag.data.market_data_cache`` to remove the
reverse dependency of the data layer on the execution layer. It runs the V2
backtest only when a cached return series is not already available.
"""

from __future__ import annotations

import hashlib
import json
import logging
import multiprocessing
import pickle
import shutil
import sqlite3
import tempfile
import time
from pathlib import Path
from typing import Any, cast

import pandas as pd

from leadlag.config.loader import load_yaml_with_base
from leadlag.core.market_calendar import count_tse_bdays, previous_trading_day
from leadlag.data.cache_store import SqliteCacheStore
from leadlag.data.market_data_cache import load_df_exec_from_local_cache
from leadlag.execution.config import load_config_from_yaml
from leadlag.execution.var_cache import DeadlineBudget, build_var_cache_key
from leadlag.utils.dataframe_fingerprint import dataframe_fingerprint
from leadlag.utils.threading import run_with_timeout

logger = logging.getLogger(__name__)


def _file_manifest_fingerprint(path: Path | None, *, timeout: float | None = None) -> str:
    """Fingerprint the contents of a model/data input path.

    SQLite WAL databases can receive a committed update without changing the
    main file's mtime.  Content digests therefore include the database's WAL
    and SHM sidecars when present, as well as every file in a directory.
    """
    if path is None:
        return "none"
    deadline = time.monotonic() + timeout if timeout is not None else None

    def remaining() -> None:
        if deadline is not None and time.monotonic() >= deadline:
            raise TimeoutError(f"fingerprint exceeded {timeout}s deadline")

    path = Path(path)
    remaining()
    if not path.exists():
        return f"missing:{path}"
    digest = hashlib.sha256()

    def add_file(label: str, file_path: Path) -> None:
        remaining()
        digest.update(label.encode("utf-8"))
        digest.update(b"\0")
        with file_path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                remaining()
                digest.update(chunk)
        digest.update(b"\0")

    if path.is_file():
        candidates = [path]
        # WAL/SHM sidecars contain committed state that may not yet have been
        # checkpointed into the SQLite main file.
        if path.suffix in {".sqlite", ".sqlite3", ".db"}:
            candidates.extend(
                path.with_name(path.name + suffix)
                for suffix in ("-wal", "-shm")
                if path.with_name(path.name + suffix).exists()
            )
        for candidate in candidates:
            if candidate.exists():
                add_file(candidate.name, candidate)
    else:
        for child in sorted(
            p
            for p in path.rglob("*")
            if p.is_file() and p.suffix != ".pyc" and "__pycache__" not in p.parts
        ):
            add_file(str(child.relative_to(path)), child)
    remaining()
    return digest.hexdigest()[:16]


def _copy_file_with_deadline(
    source: Path,
    target: Path,
    remaining: Any,
) -> None:
    """Copy one file while checking the caller's absolute deadline per chunk."""
    remaining()
    target.parent.mkdir(parents=True, exist_ok=True)
    with source.open("rb") as source_handle, target.open("wb") as target_handle:
        for chunk in iter(lambda: source_handle.read(1024 * 1024), b""):
            remaining()
            target_handle.write(chunk)
    remaining()
    shutil.copystat(source, target, follow_symlinks=True)


def _copy_directory_with_deadline(
    source: Path,
    target: Path,
    remaining: Any,
) -> None:
    """Copy a directory without an uninterruptible ``copytree`` call."""
    remaining()
    target.mkdir(parents=True, exist_ok=False)
    for child in sorted(source.rglob("*")):
        remaining()
        relative = child.relative_to(source)
        destination = target / relative
        if child.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
        elif child.is_file():
            _copy_file_with_deadline(child, destination, remaining)
    remaining()


def _active_overlay_artifact_fingerprint(path: Path | None) -> str:
    """Fingerprint only the version selected by an overlay ``CURRENT`` pointer.

    Staging directories and inactive versions are intentionally excluded: they
    cannot affect the model used by a VaR/ES backtest and must not invalidate a
    return cache. The selected version id is included even if two versions
    happen to contain identical bytes.
    """
    if path is None:
        return "none"
    path = Path(path)
    if not path.exists():
        return f"missing:{path}"
    if path.is_file():
        return _file_manifest_fingerprint(path)

    current_path = path / "CURRENT"
    if not current_path.exists():
        # The overlay loader rejects this legacy layout. Keep its two relevant
        # files visible in the key so a config repair cannot reuse this cache.
        legacy_files = [candidate for candidate in (path / "model.pkl", path / "metadata.json") if candidate.exists()]
        if not legacy_files:
            return f"missing-current:{path}"
        digest = hashlib.sha256(b"legacy-root-overlay\0")
        for candidate in legacy_files:
            digest.update(candidate.name.encode("utf-8"))
            digest.update(candidate.read_bytes())
        return digest.hexdigest()[:16]
    try:
        version = current_path.read_text(encoding="utf-8").strip()
    except OSError as exc:
        return f"unreadable-current:{path}:{type(exc).__name__}"
    if not version or version in {".", ".."} or Path(version).name != version:
        return f"invalid-current:{path}:{version!r}"
    active_dir = path / "versions" / version
    if not active_dir.is_dir():
        return f"missing-active-version:{path}:{version}"
    return f"active:{version}:{_file_manifest_fingerprint(active_dir)}"


def _snapshot_gap_input(
    path: Path | None,
    *,
    timeout: float | None = None,
) -> tuple[Path | None, str, tempfile.TemporaryDirectory[str] | None]:
    """Create one immutable gap-input snapshot and its cache identity.

    A risk cache key must describe the exact input consumed by its backtest.
    SQLite's backup API takes a transactionally consistent copy, including
    committed WAL state.  Directory-backed ``.npy`` inputs are copied only
    after a before/after content fingerprint agrees; otherwise the copy is
    retried so a writer cannot publish a mixed generation during the copy.
    The temporary-directory object is returned to keep the snapshot alive for
    the duration of the caller (including a timeout worker thread).
    """
    if path is None:
        return None, "none", None
    path = Path(path)
    if not path.exists():
        return None, _file_manifest_fingerprint(path), None

    deadline = time.monotonic() + timeout if timeout is not None else None

    def remaining() -> float | None:
        if deadline is None:
            return None
        left = deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError(f"gap-input snapshot exceeded {timeout}s deadline")
        return left

    last_error: Exception | None = None
    for _attempt in range(3):
        temporary = tempfile.TemporaryDirectory(prefix="leadlag-gap-snapshot-")
        try:
            left = remaining()
            before = _file_manifest_fingerprint(path, timeout=remaining())
            if path.is_file() and path.suffix.lower() in {".sqlite", ".sqlite3", ".db"}:
                snapshot_path = Path(temporary.name) / "gap.sqlite"
                connect_timeout = 30.0 if left is None else max(0.01, left)
                source = sqlite3.connect(str(path), timeout=connect_timeout)
                target = sqlite3.connect(str(snapshot_path), timeout=connect_timeout)
                try:
                    # Small pages plus a progress callback bound both the
                    # copy and SQLite's busy waits to the caller's deadline.
                    def backup_progress(_status: int, _remaining: int, _total: int) -> None:
                        remaining()

                    source.backup(
                        target,
                        pages=16,
                        progress=backup_progress,
                        sleep=0.01,
                    )
                finally:
                    target.close()
                    source.close()
            elif path.is_dir():
                snapshot_path = Path(temporary.name) / "gap"
                _copy_directory_with_deadline(path, snapshot_path, remaining)
            else:
                snapshot_path = Path(temporary.name) / path.name
                _copy_file_with_deadline(path, snapshot_path, remaining)
            remaining()
            after = _file_manifest_fingerprint(path, timeout=remaining())
            if before != after:
                temporary.cleanup()
                continue
            snapshot_fingerprint = _file_manifest_fingerprint(
                snapshot_path, timeout=remaining()
            )
            if path.is_dir() and snapshot_fingerprint != after:
                # A directory copy may have crossed an atomic publication
                # boundary even when the source is stable again by the final
                # check.  Retry until the copied bytes match one source
                # generation exactly.
                temporary.cleanup()
                continue
            return snapshot_path, snapshot_fingerprint, temporary
        except TimeoutError:
            temporary.cleanup()
            raise
        except Exception as exc:  # noqa: BLE001
            last_error = exc
            temporary.cleanup()
    detail = f": {last_error}" if last_error is not None else ""
    raise RuntimeError(f"Could not obtain a stable gap-input snapshot for {path}{detail}")


def _overlay_model_fingerprint(model: Any | None) -> str:
    """Identify the exact overlay object selected for one risk calculation."""
    if model is None:
        return "none"
    metadata = getattr(model, "metadata", None)
    if isinstance(metadata, dict) and metadata.get("model_sha256"):
        identity = {
            key: metadata.get(key)
            for key in (
                "artifact_version",
                "model_sha256",
                "metadata_version",
                "train_end",
                "data_hash",
                "config_hash",
            )
        }
        return "object:" + hashlib.sha256(
            json.dumps(identity, sort_keys=True, default=str).encode("utf-8")
        ).hexdigest()[:16]
    return "object:" + hashlib.sha256(pickle.dumps(model)).hexdigest()[:16]


def _cache_set_worker(
    path: str,
    key: str,
    value: Any,
    timeout: float,
) -> None:
    """Write one cache value in an isolated process that can be terminated."""
    SqliteCacheStore(path, timeout=max(0.01, timeout)).set(key, value)


def _set_cache_with_deadline(
    path: Path,
    key: str,
    value: Any,
    *,
    timeout: float,
) -> None:
    """Atomically write a cache entry without allowing late work to survive.

    A daemon thread cannot be cancelled while SQLite is blocked in an OS call.
    Cache writes are therefore isolated in a child process; a deadline expiry
    terminates the child before it can publish a late result to the shared DB.
    """
    # ``fork`` avoids importing the complete application during a short
    # deadline on Unix.  Windows has no fork context and uses spawn instead.
    context: Any
    try:
        context = multiprocessing.get_context("fork")
    except ValueError:
        context = multiprocessing.get_context("spawn")
    process = context.Process(
        target=_cache_set_worker,
        args=(str(path), key, value, timeout),
        daemon=True,
    )
    process.start()
    process.join(timeout=timeout)
    if process.is_alive():
        process.terminate()
        process.join(timeout=1.0)
        if process.is_alive():
            process.kill()
            process.join()
        raise TimeoutError(f"cache write exceeded {timeout}s deadline")
    if process.exitcode != 0:
        raise RuntimeError(
            f"cache write process failed with exit code {process.exitcode}"
        )


def get_hist_returns_for_risk(
    strategy: Any,
    config: Any,
    output_root: str,
    trade_date: pd.Timestamp,
    config_path: str | Path | None = None,
    gap_input_dir: str | Path | None = None,
    overlay_model: Any | None = None,
) -> pd.Series:
    """Efficiently get historical daily returns for VaR/ES risk checks.

    Uses an SQLite cache if available, otherwise runs the V2 full backtest and
    caches the result. The ``strategy`` argument is kept for backward
    compatibility but is no longer used.
    """
    cache_dir = Path(output_root) / ".cache"
    # A single deadline covers snapshot acquisition and the backtest.  The
    # snapshot used to happen before the backtest timeout was even resolved,
    # so a SQLite lock could block the caller for the connection timeout.
    if isinstance(config, dict):
        configured_timeout = config.get("var_history_timeout", 300)
    else:
        configured_timeout = getattr(config, "var_history_timeout", 300)
    try:
        timeout = max(0.01, float(configured_timeout))
    except (TypeError, ValueError):
        timeout = 300.0
    deadline_budget = DeadlineBudget.from_timeout(timeout)

    def remaining_timeout() -> float:
        return deadline_budget.remaining(label="VaR/ES risk-history")

    def timed_call(function: Any, label: str) -> Any:
        """Bound synchronous preparation/cache operations by the same deadline."""
        return run_with_timeout(function, timeout=remaining_timeout(), label=label)

    try:
        returns_store = timed_call(
            lambda: SqliteCacheStore(
                cache_dir / "daily_returns.sqlite",
                timeout=remaining_timeout(),
            ),
            "VaR/ES return-cache initialization",
        )
    except TimeoutError as exc:
        logger.error("VaR/ES return-cache initialization timed out: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)

    # Load and freshness-check the source data before consulting the cache.
    # A cache hit must never hide a corrected/stale df_exec bundle.
    try:
        df_exec = timed_call(
            lambda: load_df_exec_from_local_cache(max_stale_bdays=3),
            "VaR/ES df_exec load",
        )
    except TimeoutError as exc:
        logger.error("VaR/ES df_exec load timed out: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)
    except RuntimeError as e:
        logger.error("VaR/ES cannot use stale df_exec: %s", e)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)

    # Resolve the canonical inherited config before consulting the cache.  A
    # VaR series is only reusable for the same effective config and cost
    # override; the old fixed key silently reused returns from another run.
    project_root = Path(__file__).resolve().parents[3]
    if config_path is None:
        resolved_cfg_path = project_root / "configs" / "production" / "production.yaml"
    else:
        resolved_cfg_path = Path(config_path)
        if not resolved_cfg_path.is_absolute():
            resolved_cfg_path = project_root / resolved_cfg_path
    start_date = getattr(config, "start_date", "2015-01-05")
    slippage_bps = getattr(config, "slippage_bps", None)
    try:
        effective_config = timed_call(
            lambda: load_yaml_with_base(resolved_cfg_path),
            "VaR/ES effective config load",
        )
    except TimeoutError as exc:
        logger.error("VaR/ES effective config load timed out: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)
    configured_gap_raw = effective_config.get("gap_input_dir") or effective_config.get(
        "gap_distribution_dir"
    )
    if configured_gap_raw is None and isinstance(effective_config.get("gap_distribution"), dict):
        configured_gap_raw = effective_config["gap_distribution"].get("path")
    configured_gap = (
        configured_gap_raw if isinstance(configured_gap_raw, (str, Path)) else None
    )
    gap_arg = gap_input_dir if gap_input_dir is not None else configured_gap
    gap_path = Path(gap_arg) if gap_arg else None
    if gap_path is not None and not gap_path.is_absolute():
        gap_path = project_root / gap_path
    # Freeze the exact gap input before hashing the cache key.  The same
    # snapshot path is passed to the V2 backtest below, so a concurrent Step 2
    # writer cannot change the distribution between key construction and use.
    try:
        gap_snapshot_path, gap_fingerprint, _gap_snapshot_temp = timed_call(
            lambda: _snapshot_gap_input(
                gap_path,
                timeout=remaining_timeout(),
            ),
            "VaR/ES gap-input snapshot",
        )
    except (RuntimeError, TimeoutError) as exc:
        logger.error("VaR/ES cannot obtain a stable gap-input snapshot: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)
    snapshot_owner = _gap_snapshot_temp

    def _cleanup_snapshot() -> None:
        """Release a pre-worker snapshot on every non-worker exit path."""
        nonlocal snapshot_owner
        if snapshot_owner is not None:
            snapshot_owner.cleanup()
            snapshot_owner = None

    try:
        overlay_raw = effective_config.get("ml_overlay_model_dir")
        if overlay_raw is None and isinstance(effective_config.get("ml_order_overlay"), dict):
            overlay_raw = effective_config["ml_order_overlay"].get("model_dir")
        overlay_path = Path(overlay_raw) if isinstance(overlay_raw, (str, Path)) else None
        if overlay_path is not None and not overlay_path.is_absolute():
            overlay_path = project_root / overlay_path

        # Select the overlay exactly once.  A caller such as the live V2 bridge
        # passes the object already held by ProductionRunner.  Standalone VaR
        # calls load the configured version once before computing the cache key;
        # the same object is then passed to BacktestEngine below.  Never resolve
        # CURRENT again after the key has been calculated.
        selected_overlay_model = overlay_model
        if selected_overlay_model is None:
            configured_overlay = effective_config.get("ml_overlay_enabled")
            if configured_overlay is None and isinstance(effective_config.get("ml_order_overlay"), dict):
                configured_overlay = effective_config["ml_order_overlay"].get("enabled")
            if configured_overlay and overlay_path is not None:
                from leadlag.models.ml_order_overlay import load_overlay_model

                selected_overlay_model = timed_call(
                    lambda: load_overlay_model(overlay_path),
                    "VaR/ES overlay load",
                )
        overlay_identity = timed_call(
            lambda: _overlay_model_fingerprint(selected_overlay_model),
            "VaR/ES overlay fingerprint",
        ) if selected_overlay_model is not None else "none"
        df_exec_hash = timed_call(
            lambda: dataframe_fingerprint(df_exec),
            "VaR/ES df_exec fingerprint",
        )
        code_hash = timed_call(
            lambda: _file_manifest_fingerprint(
                project_root / "src" / "leadlag",
                timeout=remaining_timeout(),
            ),
            "VaR/ES code fingerprint",
        )
        cache_key = build_var_cache_key(
            effective_config=effective_config,
            start_date=start_date,
            slippage_bps=slippage_bps,
            df_exec_hash=df_exec_hash,
            code_hash=code_hash,
            overlay_identity=overlay_identity,
            gap_input_hash=gap_fingerprint,
        )

        # VaR/ES should use returns up to the previous TSE trading day.
        # If the cache does not include the most recent completed trading day,
        # we recompute to avoid stale risk thresholds.
        _RETURNS_MAX_STALE_BDAY = 0

        try:
            cached = timed_call(
                lambda: returns_store.get(cache_key),
                "VaR/ES return-cache read",
            )
        except TimeoutError as exc:
            logger.error("VaR/ES return-cache read timed out: %s", exc)
            _cleanup_snapshot()
            logger.warning("Returning empty historical return series so risk check blocks.")
            return pd.Series(dtype=float)
        if cached is not None:
            hist_results = cached
            if not hist_results.empty:
                cached_last = pd.to_datetime(hist_results.index.max()).normalize()
                if not pd.isna(cached_last):
                    required_last = pd.Timestamp(
                        previous_trading_day(trade_date.to_pydatetime())
                    )
                    stale_bdays = count_tse_bdays(cached_last, required_last)
                    if stale_bdays <= _RETURNS_MAX_STALE_BDAY:
                        hist_returns = hist_results["daily_return"]
                        hist_returns = hist_returns[hist_returns.index < trade_date]
                        logger.info(
                            "Loaded %d cached daily returns for VaR/ES (last=%s)",
                            len(hist_returns),
                            cached_last.date(),
                        )
                        remaining_timeout()
                        _cleanup_snapshot()
                        return hist_returns
                    logger.warning(
                        "Cached daily returns are stale: last=%s, trade_date=%s, "
                        "required_last=%s, %d TSE trading days old (max=%d); recomputing.",
                        cached_last.date(),
                        trade_date.date(),
                        required_last.date(),
                        stale_bdays,
                        _RETURNS_MAX_STALE_BDAY,
                    )
                else:
                    logger.warning("Cached daily returns have no valid index; recomputing.")
            else:
                logger.warning("Cached daily returns are empty; recomputing.")

        logger.info("No return cache found; running V2 full backtest for VaR/ES...")
        # load_config_from_yaml recursively resolves __base__ and validates every
        # effective field before the backtest is started.
        try:
            app_config = timed_call(
                lambda: load_config_from_yaml(resolved_cfg_path, strict=True),
                "VaR/ES application config load",
            )
        except TimeoutError as exc:
            logger.error("VaR/ES application config load timed out: %s", exc)
            _cleanup_snapshot()
            logger.warning("Returning empty historical return series so risk check blocks.")
            return pd.Series(dtype=float)
        if slippage_bps is not None:
            costs = app_config.v2.costs.model_copy(
                update={"slippage_bps_per_side": float(slippage_bps)}
            )
            v2 = app_config.v2.model_copy(update={"costs": costs})
            app_config = app_config.model_copy(update={"v2": v2})

        if gap_input_dir is None:
            gap_input_dir = app_config.gap_distribution_dir
        gap_dir = gap_snapshot_path
        if gap_input_dir and gap_dir is None:
            logger.warning(
                "Gap input dir not found or could not be snapshotted: %s. "
                "V2 VaR/ES history will fall back to flat positions.",
                gap_input_dir,
            )

        # Local import to avoid a module-level cycle; bound it as part of the
        # same deadline because a cold import can be expensive on startup.
        def _load_backtest_engine() -> Any:
            from leadlag.execution.backtester import BacktestEngine

            return BacktestEngine

        backtest_engine = timed_call(
            _load_backtest_engine,
            "VaR/ES backtest engine import",
        )

        # Resolve the remaining budget before transferring ownership.  If the
        # overall deadline has already elapsed, the outer cleanup path still
        # owns the snapshot and can remove it deterministically.
        worker_timeout = remaining_timeout()

        # Transfer ownership to the worker before starting it.  The caller
        # must not clean this directory after a timeout while the daemon thread
        # is still reading from the snapshot.
        worker_snapshot_owner = snapshot_owner
        snapshot_owner = None

        def _run_backtest_for_risk() -> dict[str, Any]:
            # Keep the TemporaryDirectory owner in this worker's closure.  If the
            # caller's join timeout expires, the daemon worker may still be inside
            # the backtest; deleting the snapshot on caller return would otherwise
            # invalidate the very input it is reading.
            keepalive = worker_snapshot_owner
            try:
                return cast(
                    dict[str, Any],
                    backtest_engine.run_v2_backtest(
                        cfg=app_config,
                        gap_input_dir=gap_dir,
                        df_exec=df_exec,
                        start_date=start_date,
                        n_jobs=1,
                        overlay_model=selected_overlay_model,
                    ),
                )
            finally:
                if keepalive is not None:
                    keepalive.cleanup()

        try:
            out_res = run_with_timeout(
                _run_backtest_for_risk,
                timeout=worker_timeout,
                label="get_hist_returns_for_risk V2 backtest",
            )
        except TimeoutError:
            logger.warning(
                "V2 backtest for VaR/ES timed out after %d seconds; "
                "returning empty series so risk check blocks.",
                timeout,
            )
            return pd.Series(dtype=float)
    except TimeoutError as exc:
        _cleanup_snapshot()
        logger.error("VaR/ES preparation exceeded its deadline: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)
    except BaseException:
        _cleanup_snapshot()
        raise
    hist_results = pd.DataFrame(
        {"daily_return": out_res["daily_returns"]},
        index=out_res["daily_returns"].index,
    )

    try:
        _set_cache_with_deadline(
            returns_store.path,
            cache_key,
            hist_results,
            timeout=remaining_timeout(),
        )
        remaining_timeout()
    except TimeoutError as exc:
        logger.error("VaR/ES return-cache write timed out: %s", exc)
        logger.warning("Returning empty historical return series so risk check blocks.")
        return pd.Series(dtype=float)

    remaining_timeout()
    return pd.Series(
        hist_results.loc[
            hist_results.index < trade_date,
            "daily_return",
        ]
    )
