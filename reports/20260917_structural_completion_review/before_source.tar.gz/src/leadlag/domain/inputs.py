"""Versioned input contracts for the production decision boundary.

The decision engine historically accepted a dataframe, a point-in-time lake,
an optional snapshot, and a separate price mapping.  Those values could
silently disagree.  This module gives the engine one explicit contract while
keeping the old arguments available at the outer compatibility boundary.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any

import numpy as np
import pandas as pd


def _timestamp(value: Any, name: str) -> pd.Timestamp:
    """Coerce a scalar timestamp without changing its wall-clock date."""
    if value is None:
        raise ValueError(f"{name} is required")
    result = pd.Timestamp(value)
    if pd.isna(result):
        raise ValueError(f"{name} must be a valid timestamp")
    if result.tzinfo is not None:
        result = result.tz_localize(None)
    return result


def _date(value: Any, name: str) -> pd.Timestamp:
    return _timestamp(value, name).normalize()


def _readonly_array(value: Any, name: str, *, dtype: Any = float) -> np.ndarray:
    array = np.array(value, dtype=dtype, copy=True)
    if array.ndim != 1:
        raise ValueError(f"{name} must be a one-dimensional array")
    array.setflags(write=False)
    return array


def _readonly_mapping(value: Mapping[str, Any] | None, *, numeric: bool) -> Mapping[str, Any]:
    if value is None:
        value = {}
    converted: dict[str, Any]
    if numeric:
        converted = {str(key): float(item) for key, item in value.items()}
    else:
        converted = {str(key): str(item) for key, item in value.items()}
    return MappingProxyType(converted)


def _digest(payload: Any) -> str:
    encoded = json.dumps(payload, ensure_ascii=True, sort_keys=True, separators=(",", ":"), default=str)
    return sha256(encoded.encode("utf-8")).hexdigest()


def _array_digest(array: np.ndarray) -> dict[str, Any]:
    contiguous = np.ascontiguousarray(array)
    return {
        "dtype": str(contiguous.dtype),
        "shape": list(contiguous.shape),
        "sha256": sha256(contiguous.tobytes()).hexdigest(),
    }


def _frame_digest(frame: pd.DataFrame) -> str:
    """Return a stable digest for the schema, index, and values of a frame."""
    values = pd.util.hash_pandas_object(frame, index=True).to_numpy(dtype="uint64")
    return _digest(
        {
            "columns": [(str(column), str(frame[column].dtype)) for column in frame.columns],
            "index_dtype": str(frame.index.dtype),
            "rows": len(frame),
            "values": _array_digest(values),
        }
    )


@dataclass(frozen=True)
class InputVersion:
    """Content-addressed version of the inputs used for one decision."""

    schema_version: str
    source: str
    known_fingerprint: str
    historical_fingerprint: str
    evaluation_fingerprint: str | None = None

    @property
    def digest(self) -> str:
        return _digest(
            {
                "schema_version": self.schema_version,
                "source": self.source,
                "known": self.known_fingerprint,
                "historical": self.historical_fingerprint,
                "evaluation": self.evaluation_fingerprint,
            }
        )


@dataclass(frozen=True)
class KnownMarketInputs:
    """Values known at the decision timestamp for one execution date."""

    trade_date: pd.Timestamp
    as_of: pd.Timestamp
    ticker_order: tuple[str, ...]
    us_returns: np.ndarray
    jp_gap_returns: np.ndarray
    jp_betas: np.ndarray
    topix_night_return: float
    current_prices: Mapping[str, float] = field(default_factory=dict)
    prev_closes: Mapping[str, float] = field(default_factory=dict)
    macro_features: Mapping[str, float] = field(default_factory=dict)
    adr_features: Mapping[str, float] = field(default_factory=dict)
    sig_date: pd.Timestamp | None = None
    observed_at: Mapping[str, str] = field(default_factory=dict)
    source: str = "unknown"

    def __post_init__(self) -> None:
        trade_date = _date(self.trade_date, "trade_date")
        as_of = _timestamp(self.as_of, "as_of")
        sig_date = None if self.sig_date is None else _date(self.sig_date, "sig_date")
        if sig_date is not None and sig_date >= trade_date:
            raise ValueError("sig_date must be strictly earlier than trade_date")
        tickers = tuple(str(item) for item in self.ticker_order)
        if not tickers or len(set(tickers)) != len(tickers):
            raise ValueError("ticker_order must contain unique tickers")

        us_returns = _readonly_array(self.us_returns, "us_returns")
        jp_gap_returns = _readonly_array(self.jp_gap_returns, "jp_gap_returns")
        jp_betas = _readonly_array(self.jp_betas, "jp_betas")
        if len(jp_gap_returns) != len(tickers) or len(jp_betas) != len(tickers):
            raise ValueError("JP arrays must match ticker_order length")

        object.__setattr__(self, "trade_date", trade_date)
        object.__setattr__(self, "as_of", as_of)
        object.__setattr__(self, "sig_date", sig_date)
        object.__setattr__(self, "ticker_order", tickers)
        object.__setattr__(self, "us_returns", us_returns)
        object.__setattr__(self, "jp_gap_returns", jp_gap_returns)
        object.__setattr__(self, "jp_betas", jp_betas)
        object.__setattr__(self, "topix_night_return", float(self.topix_night_return))
        object.__setattr__(self, "current_prices", _readonly_mapping(self.current_prices, numeric=True))
        object.__setattr__(self, "prev_closes", _readonly_mapping(self.prev_closes, numeric=True))
        object.__setattr__(self, "macro_features", _readonly_mapping(self.macro_features, numeric=True))
        object.__setattr__(self, "adr_features", _readonly_mapping(self.adr_features, numeric=True))
        object.__setattr__(self, "observed_at", _readonly_mapping(self.observed_at, numeric=False))

    @property
    def fingerprint(self) -> str:
        return _digest(
            {
                "trade_date": self.trade_date.isoformat(),
                "as_of": self.as_of.isoformat(),
                "sig_date": None if self.sig_date is None else self.sig_date.isoformat(),
                "ticker_order": self.ticker_order,
                "us_returns": _array_digest(self.us_returns),
                "jp_gap_returns": _array_digest(self.jp_gap_returns),
                "jp_betas": _array_digest(self.jp_betas),
                "topix_night_return": self.topix_night_return,
                "current_prices": dict(self.current_prices),
                "prev_closes": dict(self.prev_closes),
                "macro_features": dict(self.macro_features),
                "adr_features": dict(self.adr_features),
                "observed_at": dict(self.observed_at),
                "source": self.source,
            }
        )


@dataclass(frozen=True, init=False)
class HistoricalInputs:
    """Historical frame and PIT training metadata owned by a decision run.

    The constructor takes a deep copy.  Callers receive a copy through
    ``to_frame``; the calculation path uses the private, owned frame through
    ``calculation_frame`` so a backtest does not copy the full history once per
    simulated day.
    """

    _frame: pd.DataFrame = field(repr=False)
    horizon: int
    baseline_start: pd.Timestamp
    baseline_end: pd.Timestamp
    pit_ir_history: np.ndarray | None
    label_available_at: Mapping[str, str]
    source: str

    def __init__(
        self,
        frame: pd.DataFrame,
        *,
        horizon: int = 1,
        baseline_start: Any = "2010-01-01",
        baseline_end: Any = "2014-12-31",
        pit_ir_history: Any | None = None,
        label_available_at: Mapping[str, str] | None = None,
        source: str = "unknown",
    ) -> None:
        if not isinstance(frame, pd.DataFrame) or frame.empty:
            raise ValueError("historical frame must be a non-empty DataFrame")
        if int(horizon) < 1:
            raise ValueError("horizon must be >= 1")
        start = _date(baseline_start, "baseline_start")
        end = _date(baseline_end, "baseline_end")
        if start > end:
            raise ValueError("baseline_start must be <= baseline_end")
        if start != pd.Timestamp("2010-01-01") or end != pd.Timestamp("2014-12-31"):
            raise ValueError("HistoricalInputs baseline must remain fixed at 2010-01-01..2014-12-31")
        owned = frame.copy(deep=True)
        if not isinstance(owned.index, pd.DatetimeIndex):
            owned.index = pd.to_datetime(owned.index)
        owned = owned.sort_index()
        history = None if pit_ir_history is None else _readonly_array(pit_ir_history, "pit_ir_history")
        object.__setattr__(self, "_frame", owned)
        object.__setattr__(self, "horizon", int(horizon))
        object.__setattr__(self, "baseline_start", start)
        object.__setattr__(self, "baseline_end", end)
        object.__setattr__(self, "pit_ir_history", history)
        object.__setattr__(self, "label_available_at", _readonly_mapping(label_available_at, numeric=False))
        object.__setattr__(self, "source", str(source))

    @property
    def frame(self) -> pd.DataFrame:
        return self.to_frame()

    def to_frame(self) -> pd.DataFrame:
        """Return an isolated frame for a caller that may mutate it."""
        return self._frame.copy(deep=True)

    def calculation_frame(self) -> pd.DataFrame:
        """Return the run-owned frame for internal, read-only-by-convention use."""
        return self._frame

    @property
    def fingerprint(self) -> str:
        return _digest(
            {
                "frame": _frame_digest(self._frame),
                "horizon": self.horizon,
                "baseline_start": self.baseline_start.isoformat(),
                "baseline_end": self.baseline_end.isoformat(),
                "pit_ir_history": None if self.pit_ir_history is None else _array_digest(self.pit_ir_history),
                "label_available_at": dict(self.label_available_at),
                "source": self.source,
            }
        )


@dataclass(frozen=True)
class EvaluationInputs:
    """Post-decision values used only for realized evaluation."""

    trade_date: pd.Timestamp
    target_returns: np.ndarray | None = None
    evaluation_prices: Mapping[str, float] = field(default_factory=dict)
    source: str = "unknown"

    def __post_init__(self) -> None:
        object.__setattr__(self, "trade_date", _date(self.trade_date, "trade_date"))
        target = None if self.target_returns is None else _readonly_array(self.target_returns, "target_returns")
        object.__setattr__(self, "target_returns", target)
        object.__setattr__(self, "evaluation_prices", _readonly_mapping(self.evaluation_prices, numeric=True))

    @property
    def fingerprint(self) -> str:
        return _digest(
            {
                "trade_date": self.trade_date.isoformat(),
                "target_returns": None if self.target_returns is None else _array_digest(self.target_returns),
                "evaluation_prices": dict(self.evaluation_prices),
                "source": self.source,
            }
        )


@dataclass(frozen=True)
class DecisionInputs:
    """Single input object passed from the runner to the decision engine."""

    known: KnownMarketInputs
    historical: HistoricalInputs
    evaluation: EvaluationInputs | None = None
    gap_input_dir: Path | None = None
    use_file_cache: bool = True
    schema_version: str = "decision-inputs-v1"

    def __post_init__(self) -> None:
        if self.evaluation is not None and self.evaluation.trade_date != self.known.trade_date:
            raise ValueError("evaluation trade_date must match known trade_date")
        if self.gap_input_dir is not None:
            object.__setattr__(self, "gap_input_dir", Path(self.gap_input_dir))

    @property
    def trade_date(self) -> pd.Timestamp:
        return self.known.trade_date

    @property
    def version(self) -> InputVersion:
        return InputVersion(
            schema_version=self.schema_version,
            source=self.known.source,
            known_fingerprint=self.known.fingerprint,
            historical_fingerprint=self.historical.fingerprint,
            evaluation_fingerprint=None if self.evaluation is None else self.evaluation.fingerprint,
        )

    @classmethod
    def from_parts(
        cls,
        frame: pd.DataFrame,
        *,
        trade_date: Any,
        as_of: Any,
        ticker_order: tuple[str, ...],
        us_returns: Any,
        jp_gap_returns: Any,
        jp_betas: Any,
        topix_night_return: float,
        current_prices: Mapping[str, float],
        prev_closes: Mapping[str, float],
        macro_features: Mapping[str, float] | None = None,
        adr_features: Mapping[str, float] | None = None,
        sig_date: Any | None = None,
        observed_at: Mapping[str, str] | None = None,
        gap_input_dir: Path | None = None,
        use_file_cache: bool = True,
        source: str = "unknown",
        historical: HistoricalInputs | None = None,
        label_available_at: Mapping[str, str] | None = None,
    ) -> DecisionInputs:
        known = KnownMarketInputs(
            trade_date=_date(trade_date, "trade_date"),
            as_of=_timestamp(as_of, "as_of"),
            ticker_order=ticker_order,
            us_returns=us_returns,
            jp_gap_returns=jp_gap_returns,
            jp_betas=jp_betas,
            topix_night_return=topix_night_return,
            current_prices=current_prices,
            prev_closes=prev_closes,
            macro_features=macro_features or {},
            adr_features=adr_features or {},
            sig_date=sig_date,
            observed_at=observed_at or {},
            source=source,
        )
        return cls(
            known=known,
            historical=historical or HistoricalInputs(
                frame,
                source=source,
                label_available_at=label_available_at,
            ),
            gap_input_dir=gap_input_dir,
            use_file_cache=use_file_cache,
        )


__all__ = [
    "DecisionInputs",
    "EvaluationInputs",
    "HistoricalInputs",
    "InputVersion",
    "KnownMarketInputs",
]
