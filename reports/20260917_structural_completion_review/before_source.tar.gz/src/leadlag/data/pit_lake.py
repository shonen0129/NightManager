"""Point-in-Time (PIT) Data Lake & Snapshot Engine.

Ensures absolute temporal integrity by allowing data access ONLY via
as_of timestamps.未来データへのアクセスを型とAPIレベルで物理的に遮断
(By-Construction Leak Prevention).
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

import numpy as np
import pandas as pd

from leadlag.data.tickers import JP_TICKERS, US_TICKERS
from leadlag.domain.inputs import DecisionInputs, HistoricalInputs, KnownMarketInputs

logger = logging.getLogger(__name__)


class PITLookaheadError(Exception):
    """Raised when an attempt is made to access data from the future."""
    pass


@dataclass(frozen=True)
class MarketSnapshot:
    """Immutable Point-in-Time Market Snapshot at a specific timestamp.

    Contains only data that was finalized and known at or before ``as_of``.
    """
    as_of: pd.Timestamp
    trade_date: str  # YYYY-MM-DD
    us_returns: np.ndarray  # Shape (15,) US Close-to-Close returns (or frac-diff)
    jp_gap_returns: np.ndarray  # Shape (17,) JP 9:10 gap returns: (open / prev_close - 1)
    jp_betas: np.ndarray  # Shape (17,) Rolling TOPIX betas
    topix_night_return: float  # TOPIX overnight return
    current_prices: Mapping[str, float]  # JP tickers -> 9:10 execution prices
    prev_closes: Mapping[str, float]  # JP tickers -> previous day close prices

    def __post_init__(self) -> None:
        """Own and freeze arrays/mappings at the PIT boundary.

        ``frozen=True`` protects attribute replacement, but NumPy arrays and
        dictionaries remain mutable unless they are explicitly copied here.
        A snapshot is therefore safe to pass between the data, model, and
        execution layers without one layer changing another layer's inputs.
        """
        arrays = ("us_returns", "jp_gap_returns", "jp_betas")
        for name in arrays:
            value = np.array(getattr(self, name), dtype=float, copy=True)
            value.setflags(write=False)
            object.__setattr__(self, name, value)
        object.__setattr__(self, "current_prices", MappingProxyType({str(k): float(v) for k, v in self.current_prices.items()}))
        object.__setattr__(self, "prev_closes", MappingProxyType({str(k): float(v) for k, v in self.prev_closes.items()}))
        object.__setattr__(self, "topix_night_return", float(self.topix_night_return))

    def to_known_inputs(
        self,
        *,
        sig_date: pd.Timestamp | str | None = None,
        observed_at: Mapping[str, str] | None = None,
        source: str = "pit_lake",
    ) -> KnownMarketInputs:
        """Convert this snapshot into the versioned known-input contract."""
        return KnownMarketInputs(
            trade_date=pd.Timestamp(self.trade_date),
            as_of=self.as_of,
            ticker_order=tuple(JP_TICKERS),
            us_returns=self.us_returns,
            jp_gap_returns=self.jp_gap_returns,
            jp_betas=self.jp_betas,
            topix_night_return=self.topix_night_return,
            current_prices=self.current_prices,
            prev_closes=self.prev_closes,
            sig_date=sig_date,
            observed_at=observed_at or {},
            source=source,
        )

    def validate(self, max_abs_return: float = 0.20) -> tuple[bool, list[str]]:
        """Run sanity checks on snapshot data (prices, returns, NaN/Inf).

        Returns:
            (is_valid, list_of_error_messages)
        """
        errors: list[str] = []

        # 1. Finite and bounded US returns
        if not np.all(np.isfinite(self.us_returns)):
            errors.append("Non-finite values detected in us_returns")
        elif np.any(np.abs(self.us_returns) > max_abs_return):
            errors.append(f"US returns exceed max_abs_return threshold ({max_abs_return:.1%})")

        # 2. Finite and bounded JP gap returns
        if not np.all(np.isfinite(self.jp_gap_returns)):
            errors.append("Non-finite values detected in jp_gap_returns")
        elif np.any(np.abs(self.jp_gap_returns) > max_abs_return):
            errors.append(f"JP gap returns exceed max_abs_return threshold ({max_abs_return:.1%})")

        # 3. Finite Betas
        if not np.all(np.isfinite(self.jp_betas)):
            errors.append("Non-finite values detected in jp_betas")

        # 4. Valid current prices (positive and finite)
        for tk in JP_TICKERS:
            price = self.current_prices.get(tk, 0.0)
            if not np.isfinite(price) or price <= 0.0:
                errors.append(f"Invalid or missing execution price for {tk}: {price}")

        return (len(errors) == 0, errors)

    def is_valid(self, max_abs_return: float = 0.20) -> bool:
        """Return True if the snapshot passes all sanity checks."""
        valid, _ = self.validate(max_abs_return=max_abs_return)
        return valid


class PITDataLake:
    """Point-in-Time Data Lake for Lead-Lag Quantitative Engine.

    Guarantees that queries for date T cannot observe any data generated after T 09:10:00 JST.
    """

    def __init__(self, df_exec: pd.DataFrame) -> None:
        """Initialize with an execution dataframe.

        Args:
            df_exec: DataFrame indexed by trade_date (Timestamp or string).
        """
        self._df = df_exec.copy()
        if not isinstance(self._df.index, pd.DatetimeIndex):
            self._df.index = pd.to_datetime(self._df.index)
        self._df = self._df.sort_index()

        self._trade_dates = self._df.index
        logger.info(
            "Initialized PITDataLake with %d dates from %s to %s",
            len(self._trade_dates),
            self._trade_dates[0].strftime("%Y-%m-%d"),
            self._trade_dates[-1].strftime("%Y-%m-%d"),
        )

    @property
    def start_date(self) -> pd.Timestamp:
        return self._trade_dates[0]

    @property
    def end_date(self) -> pd.Timestamp:
        return self._trade_dates[-1]

    @property
    def df_exec(self) -> pd.DataFrame:
        """Return an isolated compatibility copy of the execution DataFrame.

        New decision code uses ``build_decision_inputs``.  Returning a copy
        here prevents legacy callers from mutating the lake's owned history.
        """
        return self._df.copy(deep=True)

    def history_frame(self) -> pd.DataFrame:
        """Return an isolated copy for callers outside the decision boundary."""
        return self._df.copy(deep=True)

    def available_dates_up_to(self, as_of: pd.Timestamp | str) -> pd.DatetimeIndex:
        """Return trade dates that occurred on or before as_of."""
        as_of_ts = pd.to_datetime(as_of)
        return self._trade_dates[self._trade_dates <= as_of_ts]

    def get_snapshot(self, as_of: pd.Timestamp | str) -> MarketSnapshot:
        """Extract an immutable MarketSnapshot strictly available at as_of.

        Args:
            as_of: Point-in-time timestamp (or date string YYYY-MM-DD).

        Returns:
            MarketSnapshot containing strictly historical data.
        """
        as_of_ts = pd.to_datetime(as_of)

        if as_of_ts not in self._df.index:
            if as_of_ts > self._trade_dates[-1]:
                raise PITLookaheadError(
                    f"as_of {as_of} is beyond the latest available trade date "
                    f"{self._trade_dates[-1].date()}. Future data is not allowed."
                )
            if as_of_ts < self._trade_dates[0]:
                raise PITLookaheadError(
                    f"as_of {as_of} is before the earliest available trade date "
                    f"{self._trade_dates[0].date()}."
                )
            # as_of is within the lake range but not a trade date in the index.
            raise PITLookaheadError(
                f"as_of {as_of} is not a trade date in the lake. "
                f"Use available_dates_up_to({as_of}) to find the nearest prior date."
            )

        target_ts = as_of_ts

        row = self._df.loc[target_ts]
        trade_date_str = target_ts.strftime("%Y-%m-%d")

        # 1. US Returns (US close on previous US day, finalized overnight)
        # Missing or non-finite US returns are kept as NaN so that
        # MarketSnapshot.validate() rejects the snapshot instead of silently
        # feeding 0.0 into the BLPX signal.
        us_cols = [f"us_cc_{tk}" for tk in US_TICKERS]
        us_returns = np.array(
            [float(row[col]) if col in row and np.isfinite(float(row[col])) else np.nan for col in us_cols],
            dtype=float,
        )

        # 2. JP 9:10 Execution Prices & Previous Closes
        current_prices: dict[str, float] = {}
        prev_closes: dict[str, float] = {}
        jp_gap_returns = np.zeros(len(JP_TICKERS), dtype=float)
        jp_betas = np.zeros(len(JP_TICKERS), dtype=float)

        for j, tk in enumerate(JP_TICKERS):
            open_col = f"jp_open_trade_{tk}"
            close_col = f"jp_close_sig_{tk}"
            beta_col = f"jp_beta_{tk}"
            gap_col = f"jp_gap_{tk}"

            p_open = float(row.get(open_col, np.nan))
            p_prev_close = float(row.get(close_col, np.nan))
            beta_val = float(row.get(beta_col, 0.0))

            if np.isfinite(p_open) and p_open > 0.0:
                current_prices[tk] = p_open
            if np.isfinite(p_prev_close) and p_prev_close > 0.0:
                prev_closes[tk] = p_prev_close

            # Beta
            jp_betas[j] = beta_val if np.isfinite(beta_val) else 0.0

            # Gap return (use precalculated or compute on the fly)
            if gap_col in row and np.isfinite(float(row[gap_col])):
                jp_gap_returns[j] = float(row[gap_col])
            elif tk in current_prices and tk in prev_closes and prev_closes[tk] > 0.0:
                jp_gap_returns[j] = (current_prices[tk] / prev_closes[tk]) - 1.0
            else:
                jp_gap_returns[j] = 0.0

        # 3. TOPIX overnight return
        topix_night_val = float(row.get("topix_night_return", 0.0))
        topix_night_return = topix_night_val if np.isfinite(topix_night_val) else 0.0

        return MarketSnapshot(
            as_of=target_ts,
            trade_date=trade_date_str,
            us_returns=us_returns,
            jp_gap_returns=jp_gap_returns,
            jp_betas=jp_betas,
            topix_night_return=topix_night_return,
            current_prices=current_prices,
            prev_closes=prev_closes,
        )

    def build_decision_inputs(
        self,
        as_of: pd.Timestamp | str,
        *,
        snapshot: MarketSnapshot | None = None,
        current_prices: Mapping[str, float] | None = None,
        jp_gap_returns: np.ndarray | None = None,
        gap_input_dir: Path | None = None,
        use_file_cache: bool = True,
        source: str = "pit_lake",
        historical: HistoricalInputs | None = None,
    ) -> DecisionInputs:
        """Build one versioned contract from a PIT snapshot and owned history.

        Explicit prices/gaps are accepted only at this adapter boundary.  The
        model receives the resulting ``DecisionInputs`` object and no longer
        has to reconcile parallel legacy arguments.
        """
        snap = snapshot or self.get_snapshot(as_of)
        trade_date = pd.Timestamp(snap.trade_date)
        row = self._df.loc[trade_date]
        raw_sig_date = row.get("sig_date") if hasattr(row, "get") else None
        if raw_sig_date is None and hasattr(row, "get"):
            raw_sig_date = row.get("signal_date")
        if raw_sig_date is not None:
            try:
                if pd.isna(raw_sig_date):
                    raw_sig_date = None
            except (TypeError, ValueError):
                pass
        prices = snap.current_prices if current_prices is None else current_prices
        if jp_gap_returns is not None:
            gaps = jp_gap_returns
        elif current_prices is None:
            gaps = snap.jp_gap_returns
        else:
            # Legacy callers may provide live 09:10 prices without a rebuilt
            # snapshot. Recompute the gap at this adapter boundary so the
            # contract cannot combine new prices with stale row gaps.
            gaps = np.zeros(len(JP_TICKERS), dtype=float)
            for index, ticker in enumerate(JP_TICKERS):
                price = prices.get(ticker)
                previous = snap.prev_closes.get(ticker)
                if price is not None and previous is not None and previous > 0.0:
                    value = float(price) / float(previous) - 1.0
                    gaps[index] = value if np.isfinite(value) else 0.0
        return DecisionInputs.from_parts(
            self._df,
            trade_date=trade_date,
            as_of=snap.as_of,
            ticker_order=tuple(JP_TICKERS),
            us_returns=snap.us_returns,
            jp_gap_returns=gaps,
            jp_betas=snap.jp_betas,
            topix_night_return=snap.topix_night_return,
            current_prices=prices,
            prev_closes=snap.prev_closes,
            sig_date=raw_sig_date,
            gap_input_dir=gap_input_dir,
            use_file_cache=use_file_cache,
            source=source,
            historical=historical,
        )

    def validate_no_lookahead(self, test_date: pd.Timestamp | str) -> bool:
        """Audit method: verify that fetching a snapshot does not leak same-day close returns."""
        snap = self.get_snapshot(test_date)
        # Only pre-approved snapshot attributes may be present. Any same-day
        # close return/price attributes (e.g. jp_oc_returns, close_prices)
        # would indicate a look-ahead leak.
        allowed = {
            "as_of",
            "trade_date",
            "us_returns",
            "jp_gap_returns",
            "jp_betas",
            "topix_night_return",
            "current_prices",
            "prev_closes",
        }
        extra = set(vars(snap).keys()) - allowed
        if extra:
            raise PITLookaheadError(
                f"MarketSnapshot contains forbidden attributes: {extra}"
            )
        return True
