"""Intraday input adapters for 09:10 execution and target labels.

The adapter owns cache reads and the existing missing-bar fallbacks.  The
target arithmetic remains in :mod:`leadlag.data.preprocessor` and accepts the
extracted open-to-09:10 returns as an explicit input.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from leadlag.data.market_data_cache import load_intraday_cache
from leadlag.data.tickers import JP_TICKERS


def _day_data(df_5m: pd.DataFrame, dt: object) -> pd.DataFrame:
    """Return one calendar day's bars using the cache's existing date rule."""
    return df_5m[df_5m.index.date == dt]


def build_5m_910_prices(
    df_exec: pd.DataFrame,
    tickers: list[str] | None = None,
    df_5m: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Build trade-date × ticker 09:10 midpoint prices from 5m bars."""
    selected = list(JP_TICKERS if tickers is None else tickers)
    p_910 = pd.DataFrame(np.nan, index=df_exec.index, columns=selected, dtype=float)
    bars = load_intraday_cache("5m") if df_5m is None else df_5m
    if bars is None or bars.empty:
        return p_910

    for dt in pd.Series(bars.index.date).unique():
        dt_ts = pd.Timestamp(dt).normalize()
        if dt_ts not in p_910.index:
            continue
        day_data = _day_data(bars, dt)
        idx_910 = pd.Timestamp(f"{dt} 09:10:00")
        if idx_910 not in day_data.index:
            continue
        row_910 = day_data.loc[idx_910]
        for ticker in selected:
            high = row_910.get(("High", ticker))
            low = row_910.get(("Low", ticker))
            close = row_910.get(("Close", ticker))
            value = (high + low) / 2 if pd.notna(high) and pd.notna(low) else close
            if pd.notna(value) and np.isfinite(value):
                p_910.loc[dt_ts, ticker] = float(value)
    return p_910


def build_open_910_returns(
    df_exec: pd.DataFrame,
    tickers: list[str] | None = None,
    df_5m: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Extract the legacy open-to-09:10 returns used by the h=1 target.

    Missing bars, prices, and non-positive prices retain the historical zero
    fallback.  Returning a date-indexed frame makes the input explicit and
    keeps the calculation layer free of cache access.
    """
    selected = list(JP_TICKERS if tickers is None else tickers)
    returns = pd.DataFrame(np.nan, index=df_exec.index, columns=selected, dtype=float)
    bars = load_intraday_cache("5m") if df_5m is None else df_5m
    if bars is None or bars.empty:
        return returns

    for dt in pd.Series(bars.index.date).unique():
        dt_ts = pd.Timestamp(dt).normalize()
        if dt_ts not in returns.index:
            continue
        day_data = _day_data(bars, dt)
        idx_910 = pd.Timestamp(f"{dt} 09:10:00")
        row_910 = day_data.loc[idx_910] if idx_910 in day_data.index else None
        for ticker in selected:
            p_910 = np.nan
            if row_910 is not None:
                high = row_910.get(("High", ticker))
                low = row_910.get(("Low", ticker))
                close = row_910.get(("Close", ticker))
                if pd.notna(high) and pd.notna(low) and np.isfinite(high) and np.isfinite(low):
                    p_910 = (high + low) / 2
                elif pd.notna(close) and np.isfinite(close):
                    p_910 = close

            p_open_5m = np.nan
            for time_str in ("09:00:00", "09:05:00", "09:10:00"):
                idx_time = pd.Timestamp(f"{dt} {time_str}")
                if idx_time not in day_data.index:
                    continue
                row_time = day_data.loc[idx_time]
                op = row_time.get(("Open", ticker))
                cl = row_time.get(("Close", ticker))
                value = op if pd.notna(op) else cl
                if pd.notna(value) and np.isfinite(value):
                    p_open_5m = value
                    break

            if (
                pd.notna(p_910)
                and pd.notna(p_open_5m)
                and np.isfinite(p_910)
                and np.isfinite(p_open_5m)
                and p_910 > 0
                and p_open_5m > 0
            ):
                returns.loc[dt_ts, ticker] = float(p_910 / p_open_5m - 1.0)
    return returns


def compute_jp_target_returns(
    df_exec: pd.DataFrame,
    jp_tickers: list[str],
    horizon: int = 1,
    p_910_df: pd.DataFrame | None = None,
) -> np.ndarray:
    """Load required intraday inputs and delegate target arithmetic."""
    from leadlag.data.preprocessor import compute_jp_target_returns as _compute

    open_910 = None
    if horizon == 1 and p_910_df is None:
        open_910 = build_open_910_returns(df_exec, jp_tickers)
    return _compute(
        df_exec,
        jp_tickers,
        horizon=horizon,
        p_910_df=p_910_df,
        open_910_returns=open_910,
    )


__all__ = [
    "build_5m_910_prices",
    "build_open_910_returns",
    "compute_jp_target_returns",
]
