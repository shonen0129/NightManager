"""ADR feature input adapter.

Only this module owns the filesystem read and staleness policy for the
precomputed ADR feature table. Models receive a DataFrame or ``None``.
"""

from __future__ import annotations

import logging
from pathlib import Path

import pandas as pd

logger = logging.getLogger(__name__)

DEFAULT_ADR_FEATURES_PATH = (
    Path(__file__).resolve().parents[3] / "data" / "adr_features.pkl"
)


def load_adr_features(
    path: Path | str | None = None,
    trade_date: pd.Timestamp | str | None = None,
    max_stale_bdays: int = 3,
) -> pd.DataFrame | None:
    """Load ADR features when present and within the existing staleness rule."""
    artifact_path = DEFAULT_ADR_FEATURES_PATH if path is None else Path(path)
    if not artifact_path.exists():
        return None
    try:
        adr_df = pd.read_pickle(artifact_path)
        if "sig_date" in adr_df.columns:
            adr_df = adr_df.drop(columns=["sig_date"])
    except Exception as exc:
        logger.warning("Failed to load ADR features from %s: %s", artifact_path, exc)
        return None

    if trade_date is not None and not adr_df.empty:
        timestamp = pd.Timestamp(trade_date)
        latest = adr_df.index.max()
        if not (latest is None or pd.isna(latest)):
            if timestamp not in adr_df.index:
                logger.warning(
                    "ADR feature row missing for trade_date=%s (latest=%s); returning None.",
                    timestamp,
                    latest,
                )
                return None
            threshold = latest + pd.offsets.BDay(max_stale_bdays)
            if threshold < timestamp:
                logger.warning(
                    "ADR features are stale (latest=%s, trade_date=%s, max_stale_bdays=%d); returning None.",
                    latest,
                    timestamp,
                    max_stale_bdays,
                )
                return None
    return adr_df


__all__ = ["DEFAULT_ADR_FEATURES_PATH", "load_adr_features"]
