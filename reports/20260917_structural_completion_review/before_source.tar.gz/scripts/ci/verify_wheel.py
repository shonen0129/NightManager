"""Validate that a built production wheel contains only production packages."""

from __future__ import annotations

import argparse
from pathlib import Path
from zipfile import ZipFile


def verify_wheel(wheel_path: Path) -> None:
    """Fail if the wheel is empty or ships the research package."""
    if not wheel_path.is_file():
        raise FileNotFoundError(wheel_path)

    with ZipFile(wheel_path) as archive:
        members = [name for name in archive.namelist() if not name.endswith("/")]

    top_level = {name.split("/", 1)[0] for name in members}
    if "leadlag" not in top_level:
        raise RuntimeError(f"{wheel_path} does not contain the leadlag package")
    if "research" in top_level:
        raise RuntimeError(f"{wheel_path} contains the research package")

    print(f"wheel verified: {wheel_path} ({len(members)} files; research excluded)")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("wheel", type=Path)
    args = parser.parse_args()
    verify_wheel(args.wheel)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
