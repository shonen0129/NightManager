"""Structural contracts for the S2a input adapters."""

from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_core_macro_has_no_network_or_cache_io() -> None:
    """Macro math must not import yfinance or own a download cache."""
    source = (ROOT / "src/leadlag/core/macro.py").read_text()
    tree = ast.parse(source)
    imported = {
        node.names[0].name
        for node in ast.walk(tree)
        if isinstance(node, ast.Import) and node.names
    }
    assert "yfinance" not in imported
    assert "run_with_timeout" not in source
    assert "download_macro_prices" not in source


def test_model_overlay_has_no_adr_filesystem_loader() -> None:
    """ADR artifact ownership belongs to the data adapter."""
    source = (ROOT / "src/leadlag/models/ml_order_overlay.py").read_text()
    assert "def _load_adr_features" not in source
    assert "read_pickle" not in source


def test_intraday_adapter_exposes_explicit_h1_input() -> None:
    """The legacy h=1 correction is an explicit adapter output."""
    source = (ROOT / "src/leadlag/data/intraday_inputs.py").read_text()
    assert "def build_open_910_returns" in source
    assert "def compute_jp_target_returns" in source
