from __future__ import annotations

import sys
from pathlib import Path

from leadlag.execution.job_guard import (
    LEASE_CONFLICT_EXIT_CODE,
    TIMEOUT_EXIT_CODE,
    run_guarded_command,
)
from leadlag.execution.state_store import ExecutionStateStore


def _script(path: Path, body: str) -> Path:
    path.write_text(body, encoding="utf-8")
    return path


def test_guard_returns_child_code_and_writes_completion_record(tmp_path: Path) -> None:
    child = _script(tmp_path / "child.py", "raise SystemExit(7)\n")
    guard_log = tmp_path / "guard.json"
    code = run_guarded_command(
        [sys.executable, str(child)],
        scope="batch:test",
        timeout_seconds=2,
        state_db=tmp_path / "state.sqlite",
        guard_log=guard_log,
    )
    assert code == 7
    payload = guard_log.read_text(encoding="utf-8")
    assert '"status": "failed"' in payload
    assert '"return_code": 7' in payload


def test_guard_terminates_slow_process_group_at_deadline(tmp_path: Path) -> None:
    child = _script(tmp_path / "slow.py", "import time\ntime.sleep(30)\n")
    code = run_guarded_command(
        [sys.executable, str(child)],
        scope="batch:timeout",
        timeout_seconds=0.15,
        grace_seconds=0.2,
        state_db=tmp_path / "state.sqlite",
        guard_log=tmp_path / "guard.json",
    )
    assert code == TIMEOUT_EXIT_CODE
    assert '"status": "timed_out"' in (tmp_path / "guard.json").read_text(encoding="utf-8")


def test_guard_conflict_does_not_start_child(tmp_path: Path) -> None:
    store = ExecutionStateStore(tmp_path / "state.sqlite")
    lease = store.acquire_lease("batch:shared", ttl_seconds=30)
    child = _script(tmp_path / "marker.py", f"from pathlib import Path\nPath({str(tmp_path / 'started').__repr__()}).touch()\n")
    try:
        code = run_guarded_command(
            [sys.executable, str(child)],
            scope="batch:shared",
            timeout_seconds=1,
            state_db=tmp_path / "state.sqlite",
            guard_log=tmp_path / "guard.json",
        )
    finally:
        lease.release()
    assert code == LEASE_CONFLICT_EXIT_CODE
    assert not (tmp_path / "started").exists()
