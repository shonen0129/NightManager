"""Regression checks for the S7 production/research ML boundary."""

from __future__ import annotations

import inspect
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

import research.experiments.ml_overlay_training as training
from leadlag.data.tickers import JP_TICKERS
from leadlag.models.ml_order_overlay import MLOrderOverlayModel
from leadlag.models.ml_order_overlay import train_overlay_model as production_train
from leadlag.models.ml_overlay_artifact import load_overlay_model, save_overlay_model
from leadlag.models.ml_overlay_features import _build_ticker_features, overlay_continuous_columns
from leadlag.models.ml_overlay_inference import apply_overlay
from research.experiments.ml_overlay_training import train_overlay_model

ROOT = Path(__file__).resolve().parents[2]


def _training_cfg() -> SimpleNamespace:
    return SimpleNamespace(model_dump=lambda **_: {})


def test_pickle_class_path_and_canonical_module_boundaries() -> None:
    assert MLOrderOverlayModel.__module__ == "leadlag.models.ml_order_overlay"
    assert inspect.getmodule(_build_ticker_features).__name__ == (
        "leadlag.models.ml_overlay_features"
    )
    assert inspect.getmodule(apply_overlay).__name__ == "leadlag.models.ml_overlay_inference"
    assert inspect.getmodule(save_overlay_model).__name__ == "leadlag.models.ml_overlay_artifact"
    assert inspect.getmodule(load_overlay_model).__name__ == "leadlag.models.ml_overlay_artifact"
    assert inspect.getmodule(train_overlay_model).__name__ == (
        "research.experiments.ml_overlay_training"
    )
    assert overlay_continuous_columns(False)[0:3] == ["score", "mu_gap", "sigma_gap"]
    assert f"ticker_{JP_TICKERS[0]}_score" in overlay_continuous_columns(True)


def test_production_overlay_import_does_not_load_research() -> None:
    source = (ROOT / "src/leadlag/models/ml_order_overlay.py").read_text(encoding="utf-8")
    assert "from research" not in source
    assert "import research" not in source
    code = (
        "import sys; import leadlag.models.ml_order_overlay; "
        "assert not any(k == 'research' or k.startswith('research.') for k in sys.modules)"
    )
    result = subprocess.run(
        [sys.executable, "-c", code],
        cwd=ROOT,
        env={"PYTHONPATH": str(ROOT / "src")},
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr or result.stdout


def test_training_tool_points_at_research_entry() -> None:
    source = (ROOT / "tools/production/train_ml_order_overlay.py").read_text(encoding="utf-8")
    assert "from research.experiments.ml_overlay_training import train_overlay_model" in source


def test_retired_production_training_name_fails_closed() -> None:
    with pytest.raises(RuntimeError, match="research.experiments.ml_overlay_training"):
        production_train()


def test_production_package_discovery_excludes_research() -> None:
    config = (ROOT / "pyproject.toml").read_text(encoding="utf-8")
    assert 'include = ["leadlag*"]' in config
    assert "research = [" in config


def test_training_entry_records_completion(monkeypatch, tmp_path) -> None:
    model = MLOrderOverlayModel(
        lgbm=SimpleNamespace(),
        cont_cols=[],
        target_std=1.0,
        use_ticker=False,
        use_classification=False,
        per_ticker_interactions=False,
        metadata={"data_hash": "d", "config_hash": "c", "artifact_version": "v"},
    )
    events: list[dict] = []
    monkeypatch.setattr(training, "_train_overlay_model_impl", lambda **_: model)
    monkeypatch.setattr(training, "_record_training_event", lambda **event: events.append(event))

    result = train_overlay_model(
        pd.DataFrame(),
        tmp_path,
        _training_cfg(),
        "2020-01-01",
        "2020-01-02",
        tmp_path / "out",
    )
    assert result is model
    assert events[0]["status"] == "completed"
    assert events[0]["metrics"]["artifact_version"] == "v"


def test_training_entry_records_interruption(monkeypatch, tmp_path) -> None:
    events: list[dict] = []

    def fail(**_: object) -> MLOrderOverlayModel:
        raise RuntimeError("fit failed")

    monkeypatch.setattr(training, "_train_overlay_model_impl", fail)
    monkeypatch.setattr(training, "_record_training_event", lambda **event: events.append(event))
    with pytest.raises(RuntimeError, match="fit failed"):
        train_overlay_model(
            pd.DataFrame(),
            tmp_path,
            _training_cfg(),
            "2020-01-01",
            "2020-01-02",
            tmp_path / "out",
        )
    assert events[0]["status"] == "interrupted"
    assert events[0]["metrics"]["error_type"] == "RuntimeError"
