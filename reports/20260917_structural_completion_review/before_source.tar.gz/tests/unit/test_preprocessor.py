"""Tests for the data preprocessor."""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from leadlag.data.preprocessor import preprocess_data
from leadlag.data.tickers import JP_TICKERS, TOPIX_TICKER, US_TICKERS


def _make_raw(
    dates: pd.DatetimeIndex,
    us_values: float = 1.0,
    jp_open_values: float = 100.0,
    jp_close_values: float = 100.0,
) -> dict:
    us_close = pd.DataFrame(
        {tk: [us_values] * len(dates) for tk in US_TICKERS}, index=dates
    )
    jp_close = pd.DataFrame(
        {tk: [jp_close_values] * len(dates) for tk in JP_TICKERS},
        index=dates,
    )
    jp_close[TOPIX_TICKER] = jp_close_values
    jp_open = pd.DataFrame(
        {tk: [jp_open_values] * len(dates) for tk in JP_TICKERS},
        index=dates,
    )
    jp_open[TOPIX_TICKER] = jp_open_values
    return {"us_close": us_close, "jp_close": jp_close, "jp_open": jp_open}


def test_zero_open_does_not_create_inf_oc():
    """A zero JP open price must not create inf target returns."""
    dates = pd.bdate_range("2024-01-01", periods=5)
    raw = _make_raw(dates, jp_open_values=100.0, jp_close_values=101.0)
    # Make one ticker open at 0.0 on the second day
    raw["jp_open"].loc[dates[1], "1619.T"] = 0.0

    df_exec = preprocess_data(raw)

    assert not np.isinf(df_exec[[f"jp_oc_{tk}" for tk in JP_TICKERS]].values).any()
    assert not np.isinf(df_exec[[f"jp_gap_{tk}" for tk in JP_TICKERS]].values).any()
    # The broken ticker row should be skipped; if present it must be finite.
    if "jp_oc_1619.T" in df_exec.columns:
        assert np.isfinite(df_exec["jp_oc_1619.T"].values).all()


def test_zero_prev_close_does_not_create_inf_gap():
    """A zero previous close must not create inf gap returns."""
    dates = pd.bdate_range("2024-01-01", periods=5)
    raw = _make_raw(dates, jp_open_values=100.0, jp_close_values=101.0)
    raw["jp_close"].loc[dates[0], "1619.T"] = 0.0

    df_exec = preprocess_data(raw)

    assert not np.isinf(df_exec[[f"jp_gap_{tk}" for tk in JP_TICKERS]].values).any()
    # The day after a zero close on the same ticker must not be added with a fake 0 gap.
    assert dates[1] not in df_exec.index or np.isfinite(
        df_exec.loc[dates[1], "jp_gap_1619.T"]
    )


def test_zero_topix_open_does_not_create_inf_oc():
    """A non-finite or zero TOPIX open/close must not enter df_exec."""
    dates = pd.bdate_range("2024-01-01", periods=5)
    raw = _make_raw(dates, jp_open_values=100.0, jp_close_values=101.0)
    raw["jp_open"].loc[dates[1], TOPIX_TICKER] = 0.0
    raw["jp_open"].loc[dates[2], TOPIX_TICKER] = np.inf
    raw["jp_close"].loc[dates[3], TOPIX_TICKER] = 0.0

    df_exec = preprocess_data(raw)

    assert not np.isinf(df_exec["topix_oc_return"].values).any()
    assert not np.isinf(df_exec["topix_cc_trade"].values).any()
    # The non-finite TOPIX open/close days should be skipped unless it is the today placeholder.
    assert dates[1] not in df_exec.index
    assert dates[2] not in df_exec.index
    assert dates[3] not in df_exec.index


def test_provisional_zero_open_is_kept():
    """A provisional row (close not yet known) with zero open must be kept."""
    dates = pd.bdate_range("2024-01-01", periods=5)
    raw = _make_raw(dates, jp_open_values=100.0, jp_close_values=101.0)
    # Simulate today's close being unknown
    raw["jp_close"].loc[dates[-1], JP_TICKERS] = np.nan
    raw["jp_close"].loc[dates[-1], TOPIX_TICKER] = np.nan
    # yfinance-style placeholder: open is 0 because market has not opened yet
    raw["jp_open"].loc[dates[-1], JP_TICKERS] = 0.0
    raw["jp_open"].loc[dates[-1], TOPIX_TICKER] = 0.0

    df_exec = preprocess_data(raw)

    # The provisional row must target the next JP session.  The same-calendar
    # US close is not known at the current day's 09:10 decision.
    provisional_dates = df_exec.index[df_exec["is_provisional"]]
    assert len(provisional_dates) == 1
    provisional_date = pd.Timestamp(provisional_dates[0])
    assert provisional_date > dates[-1]
    assert pd.Timestamp(df_exec.loc[provisional_date, "sig_date"]) == dates[-1]
    # It must be finite for downstream consumption
    assert np.isfinite(
        df_exec.loc[provisional_date, [f"jp_open_trade_{tk}" for tk in JP_TICKERS]].values
    ).all()


def test_provisional_row_does_not_use_same_day_us_close():
    """Appending a same-day US close must not change the provisional JP input."""
    dates = pd.DatetimeIndex(["2026-08-12", "2026-08-13", "2026-08-14"])

    def build(last_us_close: float) -> dict:
        raw = _make_raw(dates, jp_open_values=100.0, jp_close_values=100.0)
        raw["us_close"].loc[dates[-1], US_TICKERS] = last_us_close
        raw["jp_close"].loc[dates[-1], JP_TICKERS] = np.nan
        raw["jp_close"].loc[dates[-1], TOPIX_TICKER] = np.nan
        raw["jp_open"].loc[dates[-1], JP_TICKERS] = 100.0
        raw["jp_open"].loc[dates[-1], TOPIX_TICKER] = 100.0
        return raw

    out = preprocess_data(build(100.0), strict_validation=True)
    provisional_dates = out.index[out["is_provisional"]]
    assert len(provisional_dates) == 1
    row = out.loc[provisional_dates[0]]
    assert pd.Timestamp(row["sig_date"]) == dates[-1]
    assert pd.Timestamp(row.name) > dates[-1]
    assert not (out.index == dates[-1]).any()


def test_us_signal_survives_jp_holiday():
    """A US session on a JP holiday must feed the next JP decision."""
    us_dates = pd.DatetimeIndex(["2024-08-07", "2024-08-08", "2024-08-09", "2024-08-12"])
    jp_dates = pd.DatetimeIndex(["2024-08-07", "2024-08-08", "2024-08-12", "2024-08-13"])
    us_values = {
        tk: [100.0, 100.0, 100.0, 110.0] for tk in US_TICKERS
    }
    jp_values = {tk: [100.0] * len(jp_dates) for tk in JP_TICKERS + [TOPIX_TICKER]}
    raw = {
        "us_close": pd.DataFrame(us_values, index=us_dates),
        "jp_close": pd.DataFrame(jp_values, index=jp_dates),
        "jp_open": pd.DataFrame(jp_values, index=jp_dates),
    }
    out = preprocess_data(raw)

    row = out.loc[pd.Timestamp("2024-08-12")]
    assert pd.Timestamp(row["sig_date"]) == pd.Timestamp("2024-08-09")
    assert row[f"us_cc_{US_TICKERS[0]}"] == pytest.approx(0.0)
    row_holiday = out.loc[pd.Timestamp("2024-08-13")]
    assert pd.Timestamp(row_holiday["sig_date"]) == pd.Timestamp("2024-08-12")
    assert row_holiday[f"us_cc_{US_TICKERS[0]}"] == pytest.approx(0.10)
