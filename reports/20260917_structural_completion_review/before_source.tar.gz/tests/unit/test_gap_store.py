"""Tests for ``leadlag.data.gap_store``."""

from __future__ import annotations

import tempfile
from pathlib import Path

import numpy as np

from leadlag.data.gap_store import GapStore, is_gap_store_path


def test_gap_store_round_trip():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)
        mu = np.array([1.0, 2.0, 3.0])
        omega = np.eye(3)

        store.put("2026-08-10", "mu", mu)
        store.put("2026-08-10", "omega", omega)

        loaded_mu = store.get("2026-08-10", "mu")
        loaded_omega = store.get("2026-08-10", "omega")

        assert loaded_mu is not None
        assert np.allclose(loaded_mu, mu)
        assert loaded_omega is not None
        assert np.allclose(loaded_omega, omega)


def test_gap_store_horizon():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)
        arr = np.array([0.1, 0.2])

        store.put("2026-08-10", "mu", arr, horizon=3)
        assert store.exists("2026-08-10", "mu", horizon=3)
        assert not store.exists("2026-08-10", "mu", horizon=5)

        loaded = store.get("2026-08-10", "mu", horizon=3)
        assert loaded is not None
        assert np.allclose(loaded, arr)


def test_gap_store_horizon_bundle_is_atomic_and_preserves_metadata():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)
        mu = np.array([0.1, 0.2])
        omega = np.eye(2)
        store.save_horizon(
            "2026-08-10",
            mu,
            omega,
            metadata={"sig_date": "2026-08-07", "horizon": 3},
            horizon=3,
        )

        loaded_mu, loaded_omega, metadata = store.load_horizon(
            "2026-08-10", horizon=3
        )
        assert loaded_mu is not None and loaded_omega is not None
        assert np.allclose(loaded_mu, mu)
        assert np.allclose(loaded_omega, omega)
        assert metadata == {"sig_date": "2026-08-07", "horizon": 3}


def test_gap_store_replace_default_horizon():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)

        store.put("2026-08-10", "mu", np.array([1.0]))
        store.put("2026-08-10", "mu", np.array([2.0]))

        loaded = store.get("2026-08-10", "mu")
        assert loaded is not None
        assert np.allclose(loaded, np.array([2.0]))

        # Ensure there is exactly one row (INSERT OR REPLACE worked).
        import sqlite3

        conn = sqlite3.connect(str(path))
        count = conn.execute("SELECT COUNT(*) FROM gap_matrices").fetchone()[0]
        conn.close()
        assert count == 1


def test_gap_store_missing():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)
        assert store.get("2026-08-10", "mu") is None


def test_gap_store_round_trip_preserves_ndarray_type():
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gap.sqlite"
        store = GapStore(path)
        mu = np.array([1.0, 2.0, 3.0])
        omega = np.eye(3)

        store.put("2026-08-10", "mu", mu)
        store.put("2026-08-10", "omega", omega)

        loaded_mu = store.get("2026-08-10", "mu")
        loaded_omega = store.get("2026-08-10", "omega")

        assert isinstance(loaded_mu, np.ndarray)
        assert isinstance(loaded_omega, np.ndarray)
        assert np.allclose(loaded_mu, mu)
        assert np.allclose(loaded_omega, omega)


def test_gap_store_import_from_directory():
    with tempfile.TemporaryDirectory() as tmp:
        gap_dir = Path(tmp) / "gap_input"
        matrices_dir = gap_dir / "matrices"
        matrices_dir.mkdir(parents=True)

        np.save(matrices_dir / "mu_gap_20260810.npy", np.array([0.1, 0.2, 0.3]))
        np.save(matrices_dir / "omega_gap_20260810.npy", np.eye(3))
        # Horizon files must not be mistaken for the default horizon=-1 matrices.
        np.save(matrices_dir / "mu_gap_h1_20260810.npy", np.array([0.1, 0.2, 0.3]))

        store_path = Path(tmp) / "gap.sqlite"
        store = GapStore(store_path)
        result = store.import_from_directory(gap_dir)

        assert result["imported"] == 1
        assert result["failed"] == 0
        assert result["total_candidates"] == 1

        mu, omega, _ = store.load("2026-08-10")
        assert mu is not None
        assert omega is not None
        assert isinstance(mu, np.ndarray)
        assert isinstance(omega, np.ndarray)


def test_is_gap_store_path():
    assert is_gap_store_path("foo.sqlite")
    assert is_gap_store_path("foo.sqlite3")
    assert is_gap_store_path("foo.db")
    assert not is_gap_store_path("foo.npy")
    assert not is_gap_store_path("/some/dir")
