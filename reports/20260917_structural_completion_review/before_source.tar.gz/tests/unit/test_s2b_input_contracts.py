"""Regression tests for the S2b versioned input boundary."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from leadlag.core.pit import PITMatrixView
from leadlag.data.pit_lake import MarketSnapshot, PITDataLake
from leadlag.data.tickers import JP_TICKERS
from leadlag.domain.inputs import DecisionInputs, HistoricalInputs, KnownMarketInputs
from leadlag.execution.config import load_config_from_yaml
from leadlag.models.production_v2 import ProductionV2Model
from leadlag.runner.production import ProductionRunner, RunnerInputs
from leadlag.utils.gap_matrix_io import save_gap_matrices


def _known() -> KnownMarketInputs:
    return KnownMarketInputs(
        trade_date=pd.Timestamp("2026-09-16"),
        as_of=pd.Timestamp("2026-09-16 09:10"),
        sig_date=pd.Timestamp("2026-09-15"),
        ticker_order=("A", "B"),
        us_returns=np.array([0.01, -0.02]),
        jp_gap_returns=np.array([0.003, -0.001]),
        jp_betas=np.array([0.8, 1.1]),
        topix_night_return=0.002,
        current_prices={"A": 100.0, "B": 200.0},
        prev_closes={"A": 99.0, "B": 201.0},
        source="test",
    )


def test_known_market_inputs_freezes_arrays_and_mappings() -> None:
    known = _known()
    with pytest.raises(ValueError):
        known.jp_gap_returns[0] = 0.5
    with pytest.raises(TypeError):
        known.current_prices["A"] = 101.0


def test_known_market_inputs_rejects_same_day_signal() -> None:
    with pytest.raises(ValueError, match="strictly earlier"):
        KnownMarketInputs(
            trade_date="2026-09-16",
            as_of="2026-09-16 09:10",
            sig_date="2026-09-16",
            ticker_order=("A",),
            us_returns=[0.0],
            jp_gap_returns=[0.0],
            jp_betas=[1.0],
            topix_night_return=0.0,
        )


def test_historical_inputs_owns_frame_and_versions_content() -> None:
    source = pd.DataFrame({"x": [1.0, 2.0]}, index=pd.to_datetime(["2026-09-16", "2026-09-15"]))
    history = HistoricalInputs(source, source="test")
    source.iloc[0, 0] = 99.0
    assert history.to_frame().iloc[0, 0] == 2.0
    isolated = history.to_frame()
    isolated.iloc[0, 0] = 88.0
    assert history.to_frame().iloc[0, 0] == 2.0
    digest = history.fingerprint
    assert len(digest) == 64


def test_decision_inputs_exposes_content_addressed_version() -> None:
    frame = pd.DataFrame({"x": [1.0]}, index=pd.to_datetime(["2026-09-16"]))
    inputs = DecisionInputs(known=_known(), historical=HistoricalInputs(frame, source="test"))
    assert inputs.trade_date == pd.Timestamp("2026-09-16")
    assert inputs.version.schema_version == "decision-inputs-v1"
    assert len(inputs.version.digest) == 64


def test_pit_snapshot_and_view_are_isolated() -> None:
    source = np.array([1.0, 2.0])
    view = PITMatrixView(source, as_of=2)
    source[0] = 99.0
    assert view.historical_range(0, 1)[0] == 1.0
    with pytest.raises(ValueError):
        view.historical_range(0, 3)

    snapshot = MarketSnapshot(
        as_of=pd.Timestamp("2026-09-16 09:10"),
        trade_date="2026-09-16",
        us_returns=np.zeros(15),
        jp_gap_returns=np.zeros(17),
        jp_betas=np.ones(17),
        topix_night_return=0.0,
        current_prices={JP_TICKERS[0]: 100.0},
        prev_closes={JP_TICKERS[0]: 99.0},
    )
    with pytest.raises(ValueError):
        snapshot.us_returns[0] = 1.0
    with pytest.raises(TypeError):
        snapshot.current_prices[JP_TICKERS[0]] = 101.0


def test_pit_lake_builds_known_and_historical_contract() -> None:
    frame = pd.DataFrame(
        {
            "sig_date": [pd.Timestamp("2026-09-15")],
            f"jp_open_trade_{JP_TICKERS[0]}": [101.0],
            f"jp_close_sig_{JP_TICKERS[0]}": [100.0],
        },
        index=pd.to_datetime(["2026-09-16"]),
    )
    inputs = PITDataLake(frame).build_decision_inputs(
        "2026-09-16",
        current_prices={JP_TICKERS[0]: 105.0},
        source="test_lake",
    )
    assert inputs.known.current_prices[JP_TICKERS[0]] == 105.0
    assert inputs.known.jp_gap_returns[0] == pytest.approx(0.05)
    assert inputs.historical.source == "test_lake"


def test_pit_lake_compatibility_frame_is_a_copy() -> None:
    frame = pd.DataFrame({"x": [1.0]}, index=pd.to_datetime(["2026-09-16"]))
    lake = PITDataLake(frame)
    exposed = lake.df_exec
    exposed.iloc[0, 0] = 99.0
    assert lake.df_exec.iloc[0, 0] == 1.0


def test_v2_model_accepts_decision_inputs_contract(tmp_path) -> None:
    cfg = load_config_from_yaml("configs/production/production.yaml", strict=True).v2.model_copy(
        deep=True,
        update={
            "gap_input_dir": str(tmp_path),
            "ml_overlay_enabled": False,
            "cs_overlay_enabled": False,
            "macro_kappa_enabled": False,
            "macro_direction_enabled": False,
        },
    )
    date = "2026-09-16"
    n_j = len(JP_TICKERS)
    assert save_gap_matrices(
        tmp_path,
        date,
        np.linspace(-0.01, 0.01, n_j),
        np.eye(n_j) * 0.01,
        metadata={"sig_date": "2026-09-15", "trade_date": date, "horizon": 1},
    )
    frame = pd.DataFrame(
        {"sig_date": [pd.Timestamp("2026-09-15")]},
        index=pd.to_datetime([date]),
    )
    lake = PITDataLake(frame)
    inputs = lake.build_decision_inputs(
        date,
        current_prices={ticker: 1000.0 for ticker in JP_TICKERS},
        gap_input_dir=tmp_path,
        source="test_model",
    )
    result = ProductionV2Model(cfg, blpx_model=None).decide(inputs=inputs, overlay_enabled=False)
    assert result.w_final.shape == (n_j,)


def test_runner_can_be_constructed_from_one_contract() -> None:
    sentinel = object()

    class CaptureModel:
        def decide(self, **kwargs):
            assert kwargs["inputs"] is inputs
            assert kwargs["use_file_cache"] is False
            return sentinel

    frame = pd.DataFrame({"x": [1.0]}, index=pd.to_datetime(["2026-09-16"]))
    inputs = DecisionInputs(
        known=_known(), historical=HistoricalInputs(frame, source="test"), use_file_cache=False
    )
    runner = object.__new__(ProductionRunner)
    runner._overlay_enabled = False
    runner.model = CaptureModel()
    assert runner.run(RunnerInputs(decision_inputs=inputs)) is sentinel
